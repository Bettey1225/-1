<?php
// 設定ファイル読み込み
require_once './conf/const.php';
// 関数ファイル読み込み
require_once './model/function.php';





//表示ファイル読み込み
session_start();

if (isset($_SESSION['user_name'])) {
$username = $_SESSION['user_name'];
}else{
    header('Location:./login.php');
    exit;
}

include_once './view/view_index.php';
 
