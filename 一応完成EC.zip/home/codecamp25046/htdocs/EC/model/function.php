<?php
//関数

//追加か更新かで分岐
//@return str insertかupdate(hiddenにしてるinputのvalue)
    function sql_kind()
    {
        if (isset($_POST['sql_kind']) === TRUE) {
        $sql_kind = $_POST['sql_kind'];
        }
        return $sql_kind;
    }

//全角半角スペースのみ入力されていないか(スペースのみの場合trueを返す)
//=始まりが半角スペースもしくは全角スペースで、それが1回以上出現して終わっている。(trim後文字数＝0でもいい。)
//@param array $data レコード取得の結果
//@return bool
    function spaceonly($data)
    {
        foreach((array)$data as $val)    
        if(mb_ereg_match("^(\s|　)+$",$val) === FALSE){
            return false;
        }
        else{
            return true;
        }
    }

//前後のスペース削除
        // preg_replace($正規表現パターン, $置換後の文字列, $置換対象) 
        //　\A:ファイルの先頭, \s:半角スペース、タブ、改行のどれか1文字, \z:ファイルの末尾
        // *:直前の文字の0回以上の繰り返し, [ ～ ]:[ ]の中のどれか1文字
        //  修飾子u:文字コードをUTF-8　デリミタとしてのスラッシュ　|:いずれかの文字列
//@param str $str,$int 入力された状態の文字列
//@return str $str,$int　変換後
    function replace($str)
    {
       $tmp = preg_replace('/\A[　\s]*|[　\s]*\z/u', '', $str);
       return $tmp;
    }    
//半角に変換(n全角数字→半角数字,r→全角英字→半角英字)
    function convert($str)
    {
       $tmp = mb_convert_kana($str,'nr',HTML_CHARACTER_SET);
       return $tmp;
    }    

//空欄で送信時にNotice回避？
    function isset_replace($str)
    {
        if (isset($str) === TRUE) {
        $str = replace($str);
        }
        return $str;
    }

//エンティティ化
//@param str  $str 変換前文字
//@return str 変換後文字
//'UTF-8'の部分はsetting.phpで定義した定数に置き換えた。

    function ent($str)
    {
        $result = array();
        foreach($str as $key=>$val){
            $result[$key] = htmlspecialchars($val, ENT_QUOTES, HTML_CHARACTER_SET);
        }
        return $result;
    }
    //2次元配列用
    function ent2($str)
    {
        $result = array();
        foreach($str as $k=>$v){
            $tmp = array();
            foreach($v as $key=>$val){
                $tmp[$key] = htmlspecialchars($val, ENT_QUOTES, HTML_CHARACTER_SET);
            }
            $result[] = $tmp; 
        }
        return $result;
    }


//DB接続の処理
//DBハンドル取得
//@return obj $dbh DBハンドル
    function get_db_connect()
    {
        try{
            // データベースに接続
            $dbh = new PDO(DSN,DB_USER,DB_PASSWD,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4'));
            $dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);    
            $dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        }catch(PDOException $e){
            echo 'DB接続できませんでした。理由：'.$e->getMessage();
        throw $e;
        }
        return $dbh;    
    }

//クエリ取得&実行(レコード取得)
//@param obj  $dbh DBハンドル
//@param str  $sql SQL文
//@return array 結果の配列
    function get_as_array($dbh, $sql)
    {
        $data = array();
        try{
            //SQL実行準備    
            $stmt = $dbh->prepare($sql);     
            //バインドなし    
            //SQL実行
            $stmt->execute();
            //レコードの取得　 
            $rows = $stmt->fetchAll();
            // 1行ずつ結果を配列で取得
            foreach ($rows as $row) {
              $data[] = $row;
            }
        } catch(PDOException $e){
        throw $e;   
        }
        return $data;    
    }

//ある1つのidの情報を取得。
//@param obj  $dbh DBハンドル
//@param str  $item_id 
//@return array 結果の配列
    function get_iddata_array($dbh,$item_id)
    {
        $sql = 'SELECT 
        item_master.item_id,
        item_master.item_name,
        item_master.price,
        item_master.img,
        item_master.status,
        item_master.create_datetime,
        item_master.update_datetime,
        item_stock_master.stock,
        item_stock_master.create_datetime,
        item_stock_master.update_datetime
        FROM item_master LEFT OUTER JOIN item_stock_master
        ON item_master.item_id = item_stock_master.item_id
        WHERE item_master.item_id = '.$item_id;
        //ORDER BY item_id ascなし
        return  get_as_array($dbh, $sql);    
    }
    
//カートテーブルのデータ取得。そのユーザーかつ選んだitemの。
     function get_cartdata1_array($dbh,$user_id,$item_id)
     {
    //     $sql = 'SELECT 
    //     cart.cart_id,
    //     cart.user_id,
    //     cart.item_id,
    //     cart.amount,
    //     cart.create_datetime,
    //     cart.update_datetime,
    //     user_master.user_id,
    //     user_master.user_name,
    //     user_master.name,
    //     user_master.mail,
    //     user_master.postalcode,
    //     user_master.address,
    //     user_master.repeat_count,
    //     user_master.status
    //     FROM cart LEFT OUTER JOIN user_master
    //     ON cart.user_id = user_master.user_id 
    //     WHERE cart.user_id = '.$user_id .' AND cart.item_id = '.$item_id;
    //     //ORDER BY item_id ascなし
    //     //コピーWHERE cart.user_id = '.$user_id .' AND cart.item_id = '.$item_id;
    //     return  get_as_array($dbh, $sql);    
    // }
        try {
            // SQL文を作成
            $sql = 'SELECT * 
            FROM cart LEFT OUTER JOIN user_master
            ON cart.user_id = user_master.user_id
            WHERE cart.user_id = ? AND cart.item_id = ?';
            // SQL文を実行する準備
            $stmt = $dbh->prepare($sql);
            // SQL文のプレースホルダに値をバインド
            $stmt->bindValue(1, $user_id, PDO::PARAM_INT);
            $stmt->bindValue(2, $item_id, PDO::PARAM_INT);
            // SQLを実行
            $r = $stmt->execute();
            // レコードの取得
            $rows = $stmt->fetchAll();
        
        } catch (PDOException $e) {
            throw $e;
        }
        return $rows;
     }
//カートテーブルのデータ取得。1ユーザーのカートすべて。
    function get_cartdata2_array($dbh,$user_id)
    {
        $sql = 'SELECT 
        user_master.user_id,
        user_master.user_name,
        user_master.name,
        user_master.mail,
        user_master.postalcode,
        user_master.address,
        user_master.repeat_count,
        user_master.status,
        cart.cart_id,
        cart.user_id,
        cart.item_id,
        cart.amount,
        cart.create_datetime,
        cart.update_datetime
        FROM cart LEFT OUTER JOIN user_master
        ON cart.user_id = user_master.user_id 
        WHERE cart.user_id = '.$user_id;
        //ORDER BY item_id ascなし

        return  get_as_array($dbh, $sql);  
    }    
//カート数量をUPDATE
    function update_cart($dbh,$cart_id,$update_amount,$date)
    {
        try{
            //SQL文作成
            $sql ='UPDATE cart
                   SET amount = ?,
                   update_datetime =? 
                   WHERE cart_id = ?';   
            //SQL実行準備    
            $stmt = $dbh->prepare($sql);  
            //バインド    
            $stmt->bindValue(1,$update_amount,PDO::PARAM_INT);
            $stmt->bindValue(2,$date,PDO::PARAM_STR);
            $stmt->bindValue(3,$cart_id,PDO::PARAM_INT);
            //SQL実行
            $result = $stmt->execute();

            //$stmt->closeCursor();
        }catch(PDOException $e){
        throw $e;    
        }    
        return $result;
    }    
//カートから商品を削除
    function delete_cartrow($dbh,$cart_id)
    {
        try{
            //SQL文作成
            $sql ='DELETE 
                   FROM cart
                   WHERE cart_id = ?';   
            //SQL実行準備    
            $stmt = $dbh->prepare($sql);  
            //バインド    
            $stmt->bindValue(1,$cart_id,PDO::PARAM_INT);
            //SQL実行
            $result = $stmt->execute();

            //$stmt->closeCursor();
        }catch(PDOException $e){
        throw $e;    
        }    
        return $result;
    }
//1ユーザーのカート内のアイテム情報取得
    function  get_cartitemdata_array($dbh,$user_id)
    {
        try{
            //SQL文作成
            $sql = 'SELECT *
            FROM cart 
            INNER JOIN item_master
            ON cart.item_id = item_master.item_id
            INNER JOIN item_stock_master
            ON item_master.item_id = item_stock_master.item_id
            WHERE user_id = '.$user_id;
            //SQL実行準備    
            $stmt = $dbh->prepare($sql);  
            //バインド    

            //SQL実行
            $result = $stmt->execute();
            //$stmt->closeCursor();
        }catch(PDOException $e){
        throw $e;    
        }    
        return get_as_array($dbh, $sql);
    }    
//ユーザーマスタ取得(repeat_count計算用)
    function get_userdata_array($dbh,$user_id)
    {
        $sql = 'SELECT *
        FROM user_master
        WHERE user_master.user_id = '.$user_id;
        //ORDER BY item_id ascなし

        return  get_as_array($dbh, $sql);  
    }        
    
    
    


//リクエストメソッドを取得
//@return str POSTなど
    function get_request_method()
    {
        return $_SERVER['REQUEST_METHOD'];
    }

//POSTで送信されたデータの取得
//@param str $key 配列のキー(labelのname)
//@return str POSTで送信された値
    function get_post_data($key)
    {
        $str = '';
        if (isset($_POST[$key]) === TRUE) {
            $str = $_POST[$key];
        }
        return $str;
    }

//アップロードした画像ファイルをディレクトリへ保存
//@param str $new_img 

    function upload_img($img_dir,$new_img,$err_msg)
    {
        
        if (is_uploaded_file($_FILES['new_img']['tmp_name']) === TRUE) {
            //画像の拡張子取得
            $extension = pathinfo($_FILES['new_img']['name'], PATHINFO_EXTENSION);
            //拡張子チェック
            if ($extension === 'jpg' || $extension === 'jpeg' || $extension === 'png'
                || $extension === 'JPG' || $extension === 'JPEG' || $extension === 'PNG' ) {
              //保存する新しいファイル名の生成（ユニークな値）
              $new_img = sha1(uniqid(mt_rand(), true)). '.' . $extension;
              //同名ファイルの存在チェック
              if (is_file($img_dir . $new_img) !== TRUE) {
                //アップロードされたファイルを指定ディレクトリに移動して保存
                if (move_uploaded_file($_FILES['new_img']['tmp_name'], $img_dir . $new_img) !== TRUE) {
                    $err_msg[] = 'ファイルアップロードに失敗しました';
                }
              } else {
                $err_msg[] = 'ファイルアップロードに失敗しました。(同名のファイルの存在)再度お試しください。';
              }
            } else {
              $err_msg[] = 'ファイル形式が異なります。画像ファイルはjpgかpngのみ利用可能です。';
            }
        } else {
            $err_msg[] = 'アップロードするファイルを選択してください';
        }
        //return $err_msgだと配列で返ってくる→tool.phpでのerr_msgがここだけ多次元になる。
        return array($new_img,$err_msg);
//         foreach($err_msg as $val){
//         }
// var_dump($val);
//         return $val;
    }
    function upload_img2($img_dir,$newimg,$err_msg)
    {
        
        if (is_uploaded_file($_FILES['newimg']['tmp_name']) === TRUE) {
            //画像の拡張子取得
            $extension = pathinfo($_FILES['newimg']['name'], PATHINFO_EXTENSION);
            //拡張子チェック
            if ($extension === 'jpg' || $extension === 'jpeg' || $extension === 'png'
                || $extension === 'JPG' || $extension === 'JPEG' || $extension === 'PNG' ) {
              //保存する新しいファイル名の生成（ユニークな値）
              $newimg = sha1(uniqid(mt_rand(), true)). '.' . $extension;
              //同名ファイルの存在チェック
              if (is_file($img_dir . $newimg) !== TRUE) {
                //アップロードされたファイルを指定ディレクトリに移動して保存
                if (move_uploaded_file($_FILES['newimg']['tmp_name'], $img_dir . $newimg) !== TRUE) {
                    $err_msg[] = 'ファイルアップロードに失敗しました';
                }
              } else {
                $err_msg[] = 'ファイルアップロードに失敗しました。(同名のファイルの存在)再度お試しください。';
              }
            } else {
              $err_msg[] = 'ファイル形式が異なります。画像ファイルはjpgかpngのみ利用可能です。';
            }
        } else {
            $err_msg[] = 'アップロードするファイルを選択してください';
        }
        return array($newimg,$err_msg);
    }

 
 

//エラーが1つもない場合にDB接続し、入力された内容をitem_masterへINSERTで追加。
//@param obj $dbh DBハンドル
//@param str $new_name,new_img 入力された商品名
//@param int $new_price,$new_stock,$status
//@param str $date 入力時間
//@return array 商品名、値段、在庫、画像、公開状態、日時(配列)

//クエリ取得&実行(レコード追加)の場合は、
// $result[0];　// 更新したレコードの主キーの値が入ります。
// $result[1];　// 挿入された行数が入ります。
//@param obj  $dbh DBハンドル
//@param str  $sql SQL文
//@return array 結果の配列($result[1]>0なら1行以上追加された)
    function insert_item_master($dbh,$new_name,$new_price,$new_img,$status,$date)
    {
        try{
            //SQL文作成
            $sql = 'INSERT INTO item_master(item_name,price,img,status,create_datetime)
                    VALUES(?,?,?,?,?)';   
            //SQL実行準備    
            $stmt = $dbh->prepare($sql);  
            //バインド    
            $stmt->bindValue(1,$new_name,PDO::PARAM_STR);
            $stmt->bindValue(2,$new_price,PDO::PARAM_INT);
            $stmt->bindValue(3,$new_img,PDO::PARAM_STR);
            $stmt->bindValue(4,$status,PDO::PARAM_STR);
            $stmt->bindValue(5,$date,PDO::PARAM_STR);
            //SQL実行
            $result = $stmt->execute();
        }catch(PDOException $e){
        throw $e;    
        }    
        return $result;
    }

//入力内容をitem_masterへINSERTで追加したときのidと同じidでitem_stock_masterへもINSERT。
//@param obj $dbh DBハンドル
//@param int $new_stock
//@param str $date 入力時間
//@return array 商品名、値段、在庫、画像、公開状態、日時(配列)
    function insert_item_stock_master($dbh,$item_id,$new_stock,$date)
    {
        try{
            //SQL文作成
            $sql = 'INSERT INTO item_stock_master(item_id,stock,create_datetime)
                    VALUES(?,?,?)';   
            //SQL実行準備    
            $stmt = $dbh->prepare($sql);  
            //バインド    
            $stmt->bindValue(1,$item_id,PDO::PARAM_STR);
            $stmt->bindValue(2,$new_stock,PDO::PARAM_INT);;
            $stmt->bindValue(3,$date,PDO::PARAM_STR);
            //SQL実行
            $result = $stmt->execute();
        }catch(PDOException $e){
        throw $e;    
        }    
        return $result;
    }
//ユーザー追加
    function insert_user_master($dbh,$new_name,$new_username,$new_password,$new_mail
                                ,$new_tel,$new_birthdate,$new_sex,$new_postalcode
                                ,$new_address,$status,$date)
    {
        try{
            //SQL文作成
            $sql = 'INSERT INTO user_master(user_name,name,password,mail,tel,birthdate,sex,postalcode,
                    address,status,create_datetime)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?)';   
            //SQL実行準備    
            $stmt = $dbh->prepare($sql);  
            //バインド    
            $stmt->bindValue(1,$new_username,PDO::PARAM_STR);
            $stmt->bindValue(2,$new_name,PDO::PARAM_STR);
            $stmt->bindValue(3,$new_password,PDO::PARAM_STR);
            $stmt->bindValue(4,$new_mail,PDO::PARAM_STR);
            $stmt->bindValue(5,$new_tel,PDO::PARAM_STR);
            $stmt->bindValue(6,$new_birthdate,PDO::PARAM_STR);
            $stmt->bindValue(7,$new_sex,PDO::PARAM_INT);
            $stmt->bindValue(8,$new_postalcode,PDO::PARAM_STR);
            $stmt->bindValue(9,$new_address,PDO::PARAM_STR);
            $stmt->bindValue(10,$status,PDO::PARAM_STR);
            $stmt->bindValue(11,$date,PDO::PARAM_STR);
            
            //SQL実行
            $result = $stmt->execute();
        }catch(PDOException $e){
        throw $e;    
        }    
        return $result;
    }

//在庫数量をUPDATE
    function update_stock($dbh,$item_id,$update_stock,$date)
    {
        try{
            //SQL文作成
            $sql ='UPDATE item_stock_master
                   SET stock = ?,
                   update_datetime =? 
                   WHERE item_id = ?';   
            //SQL実行準備    
            $stmt = $dbh->prepare($sql);  
            //バインド    
            $stmt->bindValue(1,$update_stock,PDO::PARAM_INT);
            $stmt->bindValue(2,$date,PDO::PARAM_STR);
            $stmt->bindValue(3,$item_id,PDO::PARAM_INT);
            //SQL実行
            $result = $stmt->execute();

            //$stmt->closeCursor();
        }catch(PDOException $e){
        throw $e;    
        }    
        return $result;
    }
//公開状態をUPDATE
    function change_status($dbh,$item_id,$change_status,$date)
    {
        try{
            //SQL文作成
            $sql ='UPDATE item_master 
                   SET status = ?,
                   update_datetime =? 
                   WHERE item_id = ?';   
            //SQL実行準備    
            $stmt = $dbh->prepare($sql);  
            //バインド    
            $stmt->bindValue(1,$change_status,PDO::PARAM_INT);
            $stmt->bindValue(2,$date,PDO::PARAM_STR);
            $stmt->bindValue(3,$item_id,PDO::PARAM_INT);
            //SQL実行
            $result = $stmt->execute();
        }catch(PDOException $e){
        throw $e;    
        }    
        return $result;
    }
//userの公開状態(使用/掘り起こし対象)をUPDATE
    function change_user_status($dbh,$user_id,$change_status,$date)
    {
        try{
            //SQL文作成
            $sql ='UPDATE user_master 
                   SET status = ?,
                   update_datetime =? 
                   WHERE user_id = ?';   
            //SQL実行準備    
            $stmt = $dbh->prepare($sql);  
            //バインド    
            $stmt->bindValue(1,$change_status,PDO::PARAM_INT);
            $stmt->bindValue(2,$date,PDO::PARAM_STR);
            $stmt->bindValue(3,$user_id,PDO::PARAM_INT);
            //SQL実行
            $result = $stmt->execute();
        }catch(PDOException $e){
        throw $e;    
        }    
        return $result;
    }
//商品画像をUPDATE(古い画像削除したい)
    function change_img($dbh,$item_id,$oldimg,$img_dir,$newimg,$date){
        try{
            //SQL文作成
            $sql ='UPDATE item_master
                   SET img = ?,
                   update_datetime =? 
                   WHERE item_id = ?';   
            //SQL実行準備    
            $stmt = $dbh->prepare($sql);  
            //バインド    
            $stmt->bindValue(1,$newimg,PDO::PARAM_INT);
            $stmt->bindValue(2,$date,PDO::PARAM_STR);
            $stmt->bindValue(3,$item_id,PDO::PARAM_INT);
            //SQL実行
            $result = $stmt->execute();

            //もし古い画像が空でないとき（古い画像があるとき）削除する
            if($oldimg !== '' || $oldimg !== $newimg){
                unlink('./uploadimg/'.$oldimg);
            }
           
        }catch(PDOException $e){
        throw $e;    
        }    
        return $result;
    }
//ログイン時のユーザー情報取得
    function get_user($dbh, $check_username, $check_password) {

      try {
        // SQL文を作成
        $sql = 'SELECT * FROM user_master WHERE user_name = ? AND password = ?';
        // SQL文を実行する準備
        $stmt = $dbh->prepare($sql);
        // SQL文のプレースホルダに値をバインド
        $stmt->bindValue(1, $check_username, PDO::PARAM_STR);
        $stmt->bindValue(2, $check_password, PDO::PARAM_STR);
        // SQLを実行
        $r = $stmt->execute();
       
        // レコードの取得
        $rows = $stmt->fetchAll();
    
      } catch (PDOException $e) {
        throw $e;
      }
// var_dump($rows); 
// echo '<br>';
// exit;
      return $rows;

    }

//同じユーザー名が既に存在するかチェックするときに。トランザクションいらない
    function exist_user($dbh, $new_username){
        $exist_flag = false;  // ユーザが存在している場合はtrue

      try {
        // SQL文を作成
        $sql = 'SELECT *
            FROM user_master
            WHERE user_name = ?';
        // SQL文を実行する準備
        $stmt = $dbh->prepare($sql);
        // SQL文のプレースホルダに値をバインド
        $stmt->bindValue(1, $new_username, PDO::PARAM_STR);
        // SQLを実行
        $stmt->execute();
        // レコードの取得
        $rows = $stmt->fetchAll();
    
        if (count($rows) === 1) {
         $exist_flag = true;
        }
    
      } catch (PDOException $e) {
        throw $e;
      }
      return $exist_flag;
     }

// ユーザがログイン中かチェック
function check_user_login($url_root = "") {
  if (isset($_SESSION['user_name']) !== TRUE) {
    // loginページへリダイレクト
    redirect_login_page();
  }
}

// loginページへリダイレクト
// function redirect_login_page() {
//   $url_root = dirname($_SERVER["REQUEST_URI"]).'/';
//   header('Location: '.(empty($_SERVER["HTTPS"]) ? "http://" : "https://"). $_SERVER['HTTP_HOST'] . $url_root . 'login.php');
//   exit();
// }


// //金額をカンマ区切りに
// // ループで。
// function separate($num){
//     // 文字列にする？
//     $num = strval($num);
//     $separated = '';

//     // 1文字ずつ配列に入れる splitは区切り文字必要
//     $nums = $num.str_split('');
//     $len = $nums.length;

//     //ループで1文字ずつ後ろから追加していく
//     for( $i = 0; $i < $len; $i++){
//         $separated = $nums[($len-1)-i] + $separated;

//         // 3桁ごとにカンマ追加(iが2,5,8…の時のみ)
//         if($i % 3 === 2 && $len > 3){
//             $separated = ',' + $separated;
//         }
//     }
//     return $separated;
// }


// //金額をカンマ区切りに
    function separate($num){
        return number_format($num);  
    }






//表示用レコード取得。WHEREなし
//@param obj $dbh DBハンドル
//@return array ユーザー名、コメントコメント、日時(配列)
    // function get_post_list($dbh)
    // {
    //   // SQL生成
    //   $sql = 'SELECT user_name,user_comment,create_datetime FROM post ORDER BY create_datetime desc';
    //   // クエリ実行(別の関数にこのSQL文を渡す。)
    //   return get_as_array($dbh, $sql);
      
      
//元の。参考。
// try{
//     // データベースに接続
//     $dbh = new PDO($dsn,$username,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4'));
//     $dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);    
//     $dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
        
//     //SQL文作成
//     $sql = 'SELECT 
//             test_drink_master.drink_id,
//             test_drink_master.drink_name,
//             test_drink_master.price,
//             test_drink_master.img,
//             test_drink_stock.stock
//             FROM test_drink_master LEFT OUTER JOIN test_drink_stock
//             ON  test_drink_master.drink_id = test_drink_stock.drink_id
//             ORDER BY drink_id asc';    
//             //今回WHEREなし
//     //SQL実行準備    
//     $stmt = $dbh->prepare($sql);     
//     //バインドなし    
//     //SQL実行
//     $stmt->execute();
//      // レコードの取得
//     $rows = $stmt->fetchAll();
//     // 1行ずつ結果を配列で取得
//     foreach ($rows as $row) {
//       $data[] = $row;
//     }
// }catch(PDOException $e){
//     echo '接続できませんでした。理由：'.$e->getMessage();
// }

