<?php
// 設定ファイル読み込み
require_once './conf/const.php';
// 関数ファイル読み込み
require_once './model/function.php';


//変数初期化 
$img_dir = './uploadimg/';
$date = date('Y-m-d H:i:s');
$data = array();
$err_msg = array();
$result_msg = '';
$result = array();
$rows = array();
$change = '';
$cartdata = array();
$repeat_count = '';
 
session_start();
$user_id = $_SESSION['user_id'];

//送信ボタンがクリックされたら実行する処理
if(get_request_method() === 'POST' ){
    //返り値によって処理分岐。
    if (sql_kind() === 'purchase') {
        $user_id = '';
        $cart_id = '';
        $amount ='';
        
        $user_id = $_SESSION['user_id'];
        $dbh = get_db_connect();
        try{
            //$itemdata = get_iddata_array($dbh,$item_id);
            $cartdata = get_cartitemdata_array($dbh,$user_id);
        }catch(PDOException $e){
                //throw $e;
                $err_msg[] = '接続できませんでした。理由：'.$e->getMessage();
        }  
         //合計の計算
                $itemamount = '';
                $moneyamount = '';
        foreach ($cartdata as $value) {
            $itemamount = $itemamount + $value['amount'];
            $moneyamount = $moneyamount + $value['price'] * $value['amount'];
        }
        
//print $cartdata[0]['amount'];
//print $cartdata[0]['stock'];
//exit;

         //エラー処理
        //カートが空の場合
        //if(count($data[0]) === 0 ){
        if($itemamount === '' ){
            $err_msg[] = '商品をカートに入れてください。';
        }
        //■カート内すべてに対して処理するのでforeach
        foreach((array)$cartdata as $val){    
            //在庫チェック
            if($val['stock'] <= $val['amount']){
                $err_msg[] = '在庫が足りません 。';
            }
            //公開状態チェック
            if($val['status'] === '0'){
                $err_msg[] = '選択中の商品は非公開状態です。';
            }
        }
        
        // if($cartdata[0]['stock'] <= $cartdata[0]['amount']){
        //     $err_msg[] = '在庫が足りません 。';
        // }
        // if($cartdata[0]['status'] === '0'){
        //     $err_msg[] = '選択中の商品は非公開状態です。';
        // }
    }
    
        //エラーが1つもない場合
        //データベースに接続し、購入前の在庫数を参照。
        //購入履歴に記録。
        //購入された商品の在庫を1減らす,update_timeも更新
    if(count($err_msg) === 0){
        $dbh = get_db_connect();

        if(sql_kind() === 'purchase' ){

            //■そのユーザーのカート内の商品すべてに対して。
            foreach ($cartdata as $value) {
                try{
                    //★トランザクション開始
                    $dbh->beginTransaction();
                    
                    //$data = get_cartitemdata_array($dbh, $user_id);
                    
                    //★item_masterの在庫を減らす
                    //★購入履歴へ記録
                    try{
                        //レコード参照
                        $data = get_iddata_array($dbh,$value['item_id']);
                        $update_stock = $value['stock'] - $value['amount'];
                        //在庫数の更新
                        $result = update_stock($dbh,$value['item_id'],$update_stock,$date);
                      
                         //購入履歴へ記録。
                        $sql = "INSERT INTO purchase_history(item_id,create_datetime)
                                VALUES('".$value['item_id']."','".$date."')"; 
        
                        // // クエリ実行(関数にこのSQL文を渡す。)fetchが入ってるためにGeneralerror2053？
                        // $data = get_as_array($dbh, $sql);
                         //SQL実行準備    
                        $stmt = $dbh->prepare($sql);     
                        //バインドなし    
                        //SQL実行
                        $stmt->execute();
                        
                    }catch (PDOException $e) {
                    // ロールバック
                    $dbh->rollback();
                    // 例外をスロー
                    throw $e;
                    }
                    
                    //★そのユーザーのrepeat_countを+1
                    try{
                        //$dbh = get_db_connect();
                        $data = get_userdata_array($dbh,$user_id);
                        $repeat_count = $repeat_count +1;
                    
                        //SQL生成
                        $sql ="UPDATE user_master
                        SET repeat_count = $repeat_count,
                        update_datetime = '$date' 
                        WHERE user_id = $user_id";

                        //SQL実行準備    
                        $stmt = $dbh->prepare($sql);  
                        //バインド    
                        // $stmt->bindValue(1,$repeat_count,PDO::PARAM_INT);
                        // $stmt->bindValue(2,$date,PDO::PARAM_STR);
                        // $stmt->bindValue(3,$user_id,PDO::PARAM_INT);
                        //SQL実行
                        $result = $stmt->execute();
                        // クエリ実行(関数にこのSQL文を渡す。)
                        //$data = get_as_array($dbh, $sql);
                    }catch(PDOException $e){
                    // ロールバック
                    $dbh->rollback();
                    throw $e;
                        //$err_msg[] = '接続できませんでした。理由：'.$e->getMessage();
                    }
                    
                    //★カート内削除
                    try{
                        //$dbh = get_db_connect();
                        //$data = get_cartdata2_array($dbh,$user_id);
                        //SQL生成
                        $sql = 'DELETE
                                FROM cart 
                                WHERE user_id = '.$user_id;
                        //SQL実行準備    
                        $stmt = $dbh->prepare($sql);  
                        //バインド    
                        //SQL実行
                        $result = $stmt->execute();
                        // クエリ実行(関数にこのSQL文を渡す。)
                        //$data = get_as_array($dbh, $sql);
                    }catch(PDOException $e){
                    // ロールバック
                    $dbh->rollback();
                    throw $e;
                        //$err_msg[] = '接続できませんでした。理由：'.$e->getMessage();
                    }
                
                    //コミット 
                    $dbh->commit();   
                    $result_msg ='購入成功しました。';    
                }catch(PDOException $e){
                    //throw $e;
                    $err_msg[] = '購入処理で接続できませんでした。理由：'.$e->getMessage();
                }
            }
        }
    }
}else{
    $err_msg[] = 'エラー!カートページへ戻ってください。';
} 
 
//常に実行する処理 



//エンティティ化
//$err_msg = ent($err_msg);
$data = ent2($data);


//表示ファイル読み込み
//session_start();

if (isset($_SESSION['user_name'])) {
$username = $_SESSION['user_name'];
}else{
header('Location:./login.php');
exit;
}
include_once './view/view_purchase_result.php';

