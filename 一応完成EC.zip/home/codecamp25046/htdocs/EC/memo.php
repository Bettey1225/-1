パンくず
セッションとクッキー

//リセットcss
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/10up-sanitize.css/4.1.0/sanitize.min.css">
font-family: "serif";
font-family: "Impact";
Century
複数指定は
font-family: "YuGothic","Yu Gothic","Meiryo","ヒラギノ角ゴ","sans-serif";

#660000
//ヘッダーに。レスポンシブ用
<meta name="viewport" content="width=device-width,initial-scale=1">
//canonical
<link rel="canonical" href="正規化するURL">

<meta name="description" content="ページの内容を表す文章">
推奨 ページの内容を表す文章を100字以下程度で書きます。このタグで指定した文章は、検索結果のタイトル下に表示されます（されない場合もあります）。そのため、ユーザーのクリック率を高めるために重要です。
ただし、メタデスクリプションを書いたからと言って、直接的な検索順位上昇効果はありません。検索ユーザーのために書くようにしましょう。

<meta property="og:url" content="ページのURL" />
<meta property="og:title" content="ページのタイトル" />
<meta property="og:type" content="ページのタイプ">
<meta property="og:description" content="記事の抜粋" />
<meta property="og:image" content="画像のURL" />
<meta name="twitter:card" content="カード種類" />
<meta name="twitter:site" content="@Twitterユーザー名" />
<meta property="og:site_name" content="サイト名" />
<meta property="og:locale" content="ja_JP" />
<meta property="fb:app_id" content="appIDを入力">
重要 facebookやtwitterなどのソーシャルメディアでシェアされたときに、リンクを魅力的に表示させるための設定です。ソーシャルメディアからの流入を伸ばすために必須です。


<link rel="icon" href="画像URL" sizes="16x16" type="image/png"> 
<link rel="icon" href="画像URL" sizes="32x32" type="image/png">  
<link rel="icon" href="画像URL" sizes="48x48" type="image/png"> 
<link rel="icon" href="画像URL" sizes="62x62" type="image/png">
ファビコン
推奨 ブラウザのタブに表示されたり、ブックマークしたときのサイトアイコンとして使用される画像を指定します。様々な環境に対応するように、「16×16」のようにサイズごとにタグを用意します。
上のサンプルは、png画像を使う場合のコードです。gif画像を使いたい場合には、type="image/gif"とします。JPEG画像は使わないようにしましょう。

<link rel="apple-touch-icon-precomposed" href="画像のURL" />
サイトのブックマークアイコンとしても使われる
推奨 スマホでホーム画面にページを保存したときに使われるアイコンです。PNG形式の画像を用意・指定しましょう。150×150くらいのサイズにしておくと良いのではないかと思います。


<link rel="stylesheet" href="CSSファイルのURL">
<script src="JavaScriptファイルのURL"></script>

フィードページのURLを指定
<link rel="alternate" type="application/rss+xml" title="フィード" href="フィードページのURL" />
RSSリーダーに対して「このサイトのフィードはこのページで取得できるよ」と伝えるものになります。WordPressだと自動出力されます


分割ページ用のタグ
<link rel="prev" href="前のページのURL">
<link rel="next" href="次のページのURL">
主に1つの記事を複数ページに分割したときに使います。1ページ目のhead内には<link rel="next" href="2ページ目のURL">、最後のページには<link rel="prev" href="1つ前のページのURL">
、それ以外のページにはprev、nextの両方を使って、前後のページのURLを指定します。

電話番号やメールアドレスの変換設定
<meta name="format-detection" content="email=no,telephone=no,address=no">
ブラウザによっては、ページ内の電話番号やメールアドレス、住所を自動でリンクに変換してくれます。勝手にリンクにして欲しくないという場合に、こちらのmetaタグを指定しておきます。





