<?php
// セッション開始
session_start();

if (isset($_SESSION['user_name'])) {
$username = $_SESSION['user_name'];
}else{
$username ='';
}


// 設定ファイル読み込み
require_once './conf/const.php';
// 関数ファイル読み込み
require_once './model/function.php';


//変数初期化 
$img_dir    = './img/';
$date = date('Y-m-d H:i:s');
$data = array();
$err_msg = array();
$result_msg = '';
$sql_kind   = '';       //画面内でクリックした送信ボタンに応じて処理を振り分けるため
$result = '';
//$resultarray = array();
$rows = array();
$tmp = '';
 
//送信ボタンがクリックされたら実行する処理
if(get_request_method() === 'POST' ){
    //返り値によって処理分岐できる
    if (sql_kind() === 'insert') {
        $new_name = '';
        $new_username = '';
        $new_password = '';
        $new_mail = '';
        $new_tel = '';
        $new_birthdate = '';
        $new_sex = '';
        $new_postalcode = '';
        $new_address = '';
        $status = 0;

        //labelのnameを引数に。空でなければユーザーが入力したユーザーが入力した値が返ってくる。
        $new_name = get_post_data('input_name');
        $new_username = get_post_data('input_username');
        $new_password = get_post_data('input_password');
        $new_mail = get_post_data('input_mail');
        $new_tel = get_post_data('input_tel');
        $new_birthdate = get_post_data('input_birthdate');
        $new_sex = get_post_data('input_sex');
        $new_postalcode = get_post_data('input_postalcode');
        $new_address = get_post_data('input_address');
        $status = get_post_data('visible_status');
                
        //空欄でないか、前後にスペース等ついていないかのチェックというか置換で消す。

        $new_name = isset_replace($new_name);
        $new_username = convert(isset_replace($new_username));
        $new_password = convert(isset_replace($new_password));
        $new_mail = convert(isset_replace($new_mail));
        $new_tel = convert(isset_replace($new_tel));
        $new_birthdate = convert(isset_replace($new_birthdate));
        $new_postalcode = convert(isset_replace($new_postalcode));
        $new_address = isset_replace($new_address);

        //エラー処理
        //名前欄、発言欄いずれかが空欄・全角半角スペースのみの場合もエラーを出す。
        //文字数制限(mb_strlenは全角も半角も1文字としてカウント)
        if($new_name === '' || spaceonly($new_name) === TRUE){
            $err_msg[] = 'お名前が空欄です。';
        }
        elseif(mb_strlen($new_name) > 50){
            $err_msg[] = 'お名前は50文字以内で入力してください。';
        }
        if($new_username === '' || spaceonly($new_username) === TRUE){
            $err_msg[] = 'ユーザーIDが空欄です。';
        }
        elseif(mb_strlen($new_username) > 50 || mb_strlen($new_username) < 6){
            $err_msg[] = 'ユーザーIDは6文字以上50文字以内の半角英数字で入力してください。';
        }
        if($new_password === '' || spaceonly($new_password) === TRUE){
            $err_msg[] = 'パスワードが空欄です。';
        }
        elseif(mb_strlen($new_password) > 50 || mb_strlen($new_password) < 6){
            $err_msg[] = 'パスワードは6文字以上50文字以内の半角英数字で入力してください。';
        }        
        if($new_name === '' || spaceonly($new_name) === TRUE){
            $err_msg[] = 'メール欄が空欄です。';
        }
        elseif(mb_strlen($new_name) > 50){
            $err_msg[] = 'メールは50文字以内で入力してください。';
        }
        if($new_name === '' || spaceonly($new_name) === TRUE){
            $err_msg[] = 'tel欄が空欄です。';
        }
        elseif(mb_strlen($new_name) > 50){
            $err_msg[] = 'telは50文字以内で入力してください。';
        }
        if($new_name === '' || spaceonly($new_name) === TRUE){
            $err_msg[] = '生年月日が空欄です。';
        }
        if($new_sex === '' ){
            $err_msg[] = '性別を選択してください。';
        }
        if($new_name === '' || spaceonly($new_name) === TRUE){
            $err_msg[] = '郵便番号が空欄です。';
        }
        elseif(mb_strlen($new_name) > 50){
            $err_msg[] = '郵便番号は50文字以内で入力してください。';
        }
        if($new_name === '' || spaceonly($new_name) === TRUE){
            $err_msg[] = '住所が空欄です。';
        }
        elseif(mb_strlen($new_name) > 50){
            $err_msg[] = '住所は50文字以内で入力してください。';
        }
        // elseif(ctype_digit($new_stock) === FALSE){
        //     $err_msg[] = '在庫数は正の整数で入力してください。';
        // }
       
        // ユーザー名,パスワードチェック用
        // $username_regex = '/^[0-9a-zA-Z]{6,50}*$/';
        $username_regex = '/^[0-9a-zA-Z]{6,50}$/';
        $password_regex = '/^[0-9a-zA-Z]{6,50}$/';
        // メールアドレスチェック　　？末尾のDは何→数字以外。
        $mail_regex = '/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/iD';
        //生年月日
        $birthdate_regex = '/^[0-9]{4}-[0-9]{2}-[0-9]{2}/';
        //郵便番号
        $postalcode_regex =  '/^\d{3}[-]\d{4}$/';
        //電話番号
        $tel_regex = '/^[0-9]{2,4}-[0-9]{2,4}-[0-9]{3,4}/';
        
        // $num_regex = '/\d+/';
        
        // バリデーション実行
        // if( preg_match($num_regex, $new_price) === 0 ) {
        //   $err_msg[] = '値段は数字で入力してください。';
        // }
        if( preg_match($username_regex, $new_username) === 0 ) {
          $err_msg[] = 'ユーザーIDは6文字以上50文字以内の半角英数字で入力してください。';
        }
        if( preg_match($password_regex, $new_password) === 0 ) {
          $err_msg[] = 'パスワードは6文字以上50文字以内の半角英数字で入力してください。';
        }
        if( preg_match($mail_regex, $new_mail) === 0 ) {
          $err_msg[] = 'メールアドレスの形式が正しくありません。';
        }
        if( preg_match($birthdate_regex, $new_birthdate) === 0 ) {
          $err_msg[] = '生年月日を正しい形式で入力してください。';
        }
        if( preg_match($postalcode_regex, $new_postalcode) === 0 ) {
          $err_msg[] = '郵便番号を正しい形式で入力してください。';
        }
        if( preg_match($tel_regex, $new_tel) === 0 ) {
          $err_msg[] = '電話番号を正しい形式で入力してください。(ハイフンあり)';
        }
        
//公開状態のバリデーションをinsert,change追記        
        if($status !== '0' && $status !== '1'){
            $err_msg[] = '無効なステータスです。';
        }
        if($new_sex !== '1' && $new_sex !== '2'){
            $err_msg[] = '性別が無効なステータスです。';
        }

        //アップロードした画像ファイルをディレクトリへ保存
        //HTTP POST でファイルがアップロードされたかどうかチェック
        // list($new_img,$err_msg) = upload_img($img_dir,$new_img,$err_msg);
//var_dump($err_msg);
        
    // }elseif(sql_kind() === 'update'){
    //     $update_stock = '';
    //     $item_id = '';
    
    //     $update_stock = get_post_data('update_stock');
    //     $item_id = get_post_data('item_id');
    //     $update_stock = convert(isset_replace($update_stock));
    //     //エラーチェック
    //     if(ctype_digit($update_stock) === FALSE){
    //         $err_msg[] = '在庫数は正の整数で入力してください。';
    //     }
    
    //すでに同じユーザー名があるかチェック
        try{
        $dbh = get_db_connect();
        $result = exist_user($dbh, $new_username);
          if ($result ===TRUE) {
          $err_msg[] = '同じユーザー名が既に登録されています。';
          }
        }catch(PDOException $e){
        $err_msg[] = '接続できませんでした。理由：'.$e->getMessage();
        }
        
    }elseif(sql_kind() === 'change'){
        $change_status =''; 
        $user_id = '';
        $status ='';

        $status = get_post_data('change_visivle_status');    
        $user_id = get_post_data('user_id');

        if($status !== '0' && $status !== '1'){
            $err_msg[] = '無効なステータスです。';
        }
        if($status === '0' ){
            $change_status = 1 ;
        }
        else{
            $change_status = 0 ;
        }
    }
    
    //エラーが1つもない場合
    //データベースに接続し、入力された内容をINSERTでデータ追加。
    if(count($err_msg) === 0){
        $dbh = get_db_connect();

        if(sql_kind() === 'insert' ){
            try{
                //★トランザクション開始
                $dbh->beginTransaction();
                
                try{
                    $result = insert_user_master($dbh,$new_name,$new_username,$new_password,$new_mail
                    ,$new_tel,$new_birthdate,$new_sex,$new_postalcode,$new_address,$status,$date);
                    // // リロード対策でリダイレクト
                    // header('Location: http://'. $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    // exit;
     
                    //★同じidでitem_stock_masterへもINSERT
                    // $item_id = $dbh->LastInsertId('item_id');
                    // $result = insert_item_stock_master($dbh,$item_id,$new_stock,$date);

                    //コミット 
                    $dbh->commit();   
                    $result_msg ='新規アカウントを登録しました。';
                }catch (PDOException $e) {
                // ロールバック
                $dbh->rollback();
                // 例外をスロー
                throw $e;
                }
            }catch(PDOException $e){
            //throw $e;
            //echo '追加できませんでした。理由：'.$e->getMessage();
            $err_msg[] = '追加できませんでした。理由：'.$e->getMessage();
                
            }
        // }elseif(sql_kind() === 'update'){
        //     try{
        //         //★トランザクション開始
        //         $dbh->beginTransaction();
        //         try{
        //             $result = update_stock($dbh,$item_id,$update_stock,$date);
        //             // // リロード対策でリダイレクト
        //             // header('Location: http://'. $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
        //             // exit;
                
        //             //コミット 
        //             $dbh->commit();   
        //             $result_msg ='在庫数を変更しました。';
        //         }catch (PDOException $e) {
        //         // ロールバック
        //         $dbh->rollback();
        //         // 例外をスロー
        //         throw $e;
        //         }
        //     }catch(PDOException $e){
        //     //throw $e;
        //     //echo '在庫数を変更できませんでした。理由：'.$e->getMessage();
        //     $err_msg[] = '在庫数を変更できませんでした。理由：'.$e->getMessage();
                
        //     }
        }elseif(sql_kind() === 'change'){
            try{
                //★トランザクション開始
                $dbh->beginTransaction();
                try{
                    $result = change_user_status($dbh,$user_id,$change_status,$date);

                    //コミット 
                    $dbh->commit();   
                    $result_msg ='公開状態を変更しました。';
                }catch (PDOException $e) {
                // ロールバック
                $dbh->rollback();
                // 例外をスロー
                throw $e;
                }
            }catch(PDOException $e){
            //throw $e;
            //echo '公開状態を変更できませんでした。理由：'.$e->getMessage();
            $err_msg[] = '公開状態を変更できませんでした。理由：'.$e->getMessage();
            }
        }    
    }

    if(count($err_msg) > 0){
        if($username === 'admin00'){
        include_once './view/view_user_tool.php';
        }else{
            include_once './view/newaccount.php';
        }
    }  
} 
 


//常に実行する処理 
//データベースに接続し、すでに登録されている内容をSELECTで参照。
try{
    $dbh = get_db_connect();
    //SQL生成
    $sql = 'SELECT 
            user_master.user_id,
            user_master.user_name,
            user_master.name,
            user_master.password,
            user_master.mail,
            user_master.tel,
            user_master.birthdate,
            user_master.sex,
            user_master.postalcode,
            user_master.address,
            user_master.repeat_count,
            user_master.status,
            user_master.create_datetime,
            user_master.update_datetime 
            FROM user_master
            ORDER BY user_id asc'; 
            //今回WHEREなし。
            // FROM item_master LEFT OUTER JOIN item_stock_master
            // ON item_master.item_id = item_stock_master.item_idなし。
    // クエリ実行(関数にこのSQL文を渡す。)
    $data = get_as_array($dbh, $sql);
}catch(PDOException $e){
    $err_msg[] = '接続できませんでした。理由：'.$e->getMessage();
}
//表示順はSELECT文中にasc/desc。
//var_dump($data[0]);

//エンティティ化
$data = ent2($data);

//パスワードはviewの方で暗号化
//表示ファイル読み込み
if($username === 'admin00'){
    include_once './view/view_user_tool.php';
}else{
    include_once './reg_comp.html';
}


// // セッション開始
// session_start();
// //ログインしていない場合はログインログインページへ。してても管理者でない場合はindexへ。
// if (!isset($_SESSION['user_name'])) {
//     include_once './login.php';
// }else{
//     $username = $_SESSION['user_name'];
//     if($username !== 'admin00'){
//         include_once './index.php';
//     }
// }


//$dbh=NULL;
 
 
//書かない                    // // リロード対策でリダイレクト
                    // header('Location: http://'. $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    // exit;
             