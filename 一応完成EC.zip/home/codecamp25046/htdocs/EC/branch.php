<?php
//分岐用ページ。何も表示させない。

if(isset($_POST['']) === TRUE){
    header('Location:-.php');
}




