<?php 
// セッション開始
session_start();

if (isset($_SESSION['user_name'])) {
$username = $_SESSION['user_name'];
}else{
    include_once '../login.php';
}
?>
<!DOCTYPE HTML>
<html lang ="ja">
<head>
    <meta charset ="UTF-8">
    <title>TOPページ</title>
<!--view単体テスト時は単体テスト時は../だけどindex.phpから動かすときは./-->
    <link rel="stylesheet" href="./css/reset.css">
    <link rel="stylesheet" href="./css/header_footer.css">
    <link rel="icon" href="./img/fab.jpg" sizes="18x18" type="image/jpg">
</head>
<body>
    <header>
    <div class="header_flex">       
        <!--ロゴ-->
        <a href="./index.php"><img class="logo" src="./img/logo.png" alt="Whiskey_Restation"></a>
        
        <div>
        <p class="name"><small class="font">こんにちは<?php print $username ?>さん</small></p>

        <ul class="header_ul">
            <li class="header_li"><a class="font_li"></a></li>
            <li class="header_li"><a class="font_li" href="./about.php">About</a></li>
            <li class="header_li"><a class="font_li">Company</a></li>
            <li class="header_li"><a class="font_li">Shoplist</a></li>
            <li class="header_li"><a class="font_li">Infomation</a></li>
            <li class="header_li"><a class="font_li">Support</a></li>
            <li class="header_li"><a class="font_li" href="./logout.php">Login/out</a></li>
        </ul>
        </div>
            <!--ログイン画面へ-->
        <p><a href="./logout.php" ><img class="headericon" src="./img/key.png" alt="ログイン" ></a></p>
            <!--カートページへ-->
        <p><a href="./cart.php" ><img class="headericon" src="./img/cart.png" alt="カート"></a></p>
    </div>
    </header>
    <main>
    <table>
        <tr>
            <th>ショップ名</th>
            <td>Whiskey&nbsp;Restation</td>
        </tr>
        <tr>
            <th>コンセプト</th>
            <td>父の日やお酒好きな人へのギフトを探している人へ。<br>
            ウイスキーの豆知識や選び方、あまり知られていない飲み方を紹介します。
            </td>
        </tr>
        <tr>    
            <th>送料･お支払方法等</th>
            <td>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</td>
        </tr>
        <tr>
            <th>お問い合わせ先</th>
            <td>お問い合わせはこちらの<a href="#">フォーム</a>よりお願いいたします。</td>
        </tr>
    </table>    
    <!--<br clear="all">-->    
        <p class="to_top"><a href="./index.php">トップページへ戻る</a></p>
    </main>
    
    <footer>
        <div class="footer_left">
            <p><small class="font">株式会社XXXXXXXX&nbsp;&nbsp;TEL:0123-45-6789</small></p>
            <p><small class="font">大阪府大阪市北区梅田xx-x-x</small></p>
            <p><small class="font">&copy; Whiskey Restation All Rights Reserved.</small></p>
        </div>
        
        <div class="footer_center  font">
            
        </div>
        <div class="footer_right">
            <img src="./img/icon_f.png" alt="sns_icon1">
            <img src="./img/icon_t.png" alt="sns_icon2">
            <img src="./img/icon_i.png" alt="sns_icon3">
        </div>    
    </footer>  
</body>
</html>
  