<?php

// 設定ファイル読み込み
require_once './conf/const.php';
// 関数ファイル読み込み
require_once './model/function.php';


//変数初期化 
$img_dir    = './uploadimg/';
$date = date('Y-m-d H:i:s');
$data = array();
$err_msg = array();
$result_msg = '';
$sql_kind   = '';       //画面内でクリックした送信ボタンに応じて処理を振り分けるため
$result = '';
//$resultarray = array();
$rows = array();
$tmp = '';


 
//送信ボタンがクリックされたら実行する処理
if(get_request_method() === 'POST' ){
    //返り値によって処理分岐できる
    if (sql_kind() === 'insert') {
        $new_name = '';
        $new_price = '';
        $new_stock = '';
        $new_img = 'no_image.png';

        //labelのnameを引数に。空でなければユーザーが入力したユーザーが入力した値が返ってくる。
        $new_name = get_post_data('input_name');
        $new_price = get_post_data('input_price');
        $new_stock = get_post_data('input_stock');
//$new_img = get_post_data('new_img');
        $status = get_post_data('visible_status');
                
        //空欄でないか、前後にスペース等ついていないかのチェックというか置換で消す。
        // preg_replace($正規表現パターン, $置換後の文字列, $置換対象) 
        //　\A:ファイルの先頭, \s:半角スペース、タブ、改行のどれか1文字, \z:ファイルの末尾
        // *:直前の文字の0回以上の繰り返し, [ ～ ]:[ ]の中のどれか1文字
        //  修飾子u:文字コードをUTF-8　デリミタとしてのスラッシュ　|:いずれかの文字列
        $new_name = isset_replace($new_name);
        $new_price = convert(isset_replace($new_price));
        $new_stock = convert(isset_replace($new_stock));
    
        // $new_name = replace($new_name);
        // $new_price = convert(replace($new_price));
        // $new_stock = convert(replace($new_stock));
  
        //エラー処理
        //名前欄、発言欄いずれかが空欄・全角半角スペースのみの場合もエラーを出す。
        //文字数制限(mb_strlenは全角も半角も1文字としてカウント)
        if($new_name === '' || spaceonly($new_name) === TRUE){
            $err_msg[] = '商品名が空欄です。';
        }
        elseif(mb_strlen($new_name) > 50){
            $err_msg[] = '商品名は50文字以内で入力してください。';
        }
        if($new_price === '' || spaceonly($new_price) === TRUE){
            $err_msg[] = '値段が空欄です。';
        }
        elseif(ctype_digit($new_price) === FALSE){
            $err_msg[] = '値段は正の整数で入力してください。';
        }
        if($new_stock === '' || spaceonly($new_stock) === TRUE){
            $err_msg[] = '個数が空欄です。';
        }
        //elseif($new_stock < 0 || gettype($new_stock) === "double"){
        elseif(ctype_digit($new_stock) === FALSE){
            $err_msg[] = '在庫数は正の整数で入力してください。';
        }

        //値段と個数が数字かチェックif(is_numeric($new_price) === FALSE)でもいい?
        //↓はなぜダメだったか。桁数指定してるのに*繰り返しつけてるところ。
        //$num_regex = '/^[0-9]{1,5}*$/';
        $num_regex = '/\d+/';
        
        // バリデーション実行
        if( preg_match($num_regex, $new_price) === 0 ) {
          $err_msg[] = '値段は数字で入力してください。';
        }
        if( preg_match($num_regex, $new_stock) === 0 ) {
          $err_msg[] = '個数は数字で入力してください。';
        }
//公開状態のバリデーションをinsert,change追記        
        if($status !== '0' && $status !== '1'){
            $err_msg[] = '無効なステータスです。';
        }

        //アップロードした画像ファイルをディレクトリへ保存
        //HTTP POST でファイルがアップロードされたかどうかチェック
        list($new_img,$err_msg) = upload_img($img_dir,$new_img,$err_msg);
//var_dump($err_msg);
        
    }elseif(sql_kind() === 'update'){
        $update_stock = '';
        $item_id = '';
    
        $update_stock = get_post_data('update_stock');
        $item_id = get_post_data('item_id');
        $update_stock = convert(isset_replace($update_stock));
        //エラーチェック
        if(ctype_digit($update_stock) === FALSE){
            $err_msg[] = '在庫数は正の整数で入力してください。';
        }
    }elseif(sql_kind() === 'change'){
        $change_status =''; 
        $item_id = '';
        $status ='';

        $status = get_post_data('change_visivle_status');    
        $item_id = get_post_data('item_id');

        if($status !== '0' && $status !== '1'){
            $err_msg[] = '無効なステータスです。';
        }
        if($status === '0' ){
            $change_status = 1 ;
        }
        else{
            $change_status = 0 ;
        }
    }elseif(sql_kind() === 'imgchange'){
        $oldimg =''; 
        $item_id = '';
        $newimg ='';

        $oldimg = get_post_data('oldimg');    
        $item_id = get_post_data('item_id');
        
        list($newimg,$err_msg) = upload_img2($img_dir,$newimg,$err_msg);
    
        }
        
    
    //エラーが1つもない場合
    //データベースに接続し、入力された内容をINSERTでデータ追加。
    if(count($err_msg) === 0){
        $dbh = get_db_connect();

        if(sql_kind() === 'insert' ){
            try{
                //★トランザクション開始
                $dbh->beginTransaction();
                //すでにinsertの場合の中に書いてるのでいらない。if($sql_kind === 'insert' ){
                try{
                    $result = insert_item_master($dbh,$new_name,$new_price,$new_img,$status,$date);
                    // // リロード対策でリダイレクト
                    // header('Location: http://'. $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    // exit;
     
                    //★同じidでitem_stock_masterへもINSERT
                    $item_id = $dbh->LastInsertId('item_id');
                    $result = insert_item_stock_master($dbh,$item_id,$new_stock,$date);

                    //コミット 
                    $dbh->commit();   
                    $result_msg ='登録しました。';
                }catch (PDOException $e) {
                // ロールバック
                $dbh->rollback();
                // 例外をスロー
                throw $e;
                }
            }catch(PDOException $e){
            //throw $e;
            //echo '追加できませんでした。理由：'.$e->getMessage();
            $err_msg[] = '追加できませんでした。理由：'.$e->getMessage();
                
            }
        }elseif(sql_kind() === 'update'){
            try{
                //★トランザクション開始
                $dbh->beginTransaction();
                try{
                    $result = update_stock($dbh,$item_id,$update_stock,$date);
                    // // リロード対策でリダイレクト
                    // header('Location: http://'. $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    // exit;
                
                    //コミット 
                    $dbh->commit();   
                    $result_msg ='在庫数を変更しました。';
                }catch (PDOException $e) {
                // ロールバック
                $dbh->rollback();
                // 例外をスロー
                throw $e;
                }
            }catch(PDOException $e){
            //throw $e;
            //echo '在庫数を変更できませんでした。理由：'.$e->getMessage();
            $err_msg[] = '在庫数を変更できませんでした。理由：'.$e->getMessage();
                
            }
        }elseif(sql_kind() === 'change'){
            try{
                //★トランザクション開始
                $dbh->beginTransaction();
                try{
                    $result = change_status($dbh,$item_id,$change_status,$date);

                    //コミット 
                    $dbh->commit();   
                    $result_msg ='公開状態を変更しました。';
                }catch (PDOException $e) {
                // ロールバック
                $dbh->rollback();
                // 例外をスロー
                throw $e;
                }
            }catch(PDOException $e){
            //throw $e;
            //echo '公開状態を変更できませんでした。理由：'.$e->getMessage();
            $err_msg[] = '公開状態を変更できませんでした。理由：'.$e->getMessage();
            }
        }elseif(sql_kind() === 'change'){
            try{
                //★トランザクション開始
                $dbh->beginTransaction();
                try{
                    $result = change_status($dbh,$item_id,$change_status,$date);

                    //コミット 
                    $dbh->commit();   
                    $result_msg ='公開状態を変更しました。';
                }catch (PDOException $e) {
                // ロールバック
                $dbh->rollback();
                // 例外をスロー
                throw $e;
                }
            }catch(PDOException $e){
            //throw $e;
            //echo '公開状態を変更できませんでした。理由：'.$e->getMessage();
            $err_msg[] = '公開状態を変更できませんでした。理由：'.$e->getMessage();
            }
        }elseif(sql_kind() === 'imgchange'){
            try{
                //★トランザクション開始
                $dbh->beginTransaction();
                try{
                    $result = change_img($dbh,$item_id,$oldimg,$img_dir,$newimg,$date);
                    //コミット 
                    $dbh->commit();   
                    $result_msg ='商品画像を変更しました。';
                }catch (PDOException $e) {
                // ロールバック
                $dbh->rollback();
                // 例外をスロー
                throw $e;
                }
            }catch(PDOException $e){
            $err_msg[] = '商品画像を変更できませんでした。理由：'.$e->getMessage();
            }  
        }
    }
} 
 

//常に実行する処理 
//データベースに接続し、すでに登録されている内容をSELECTで参照。
try{
    $dbh = get_db_connect();
    //SQL生成
    $sql = 'SELECT 
            item_master.item_id,
            item_master.item_name,
            item_master.price,
            item_master.img,
            item_master.status,
            item_stock_master.stock
            FROM item_master LEFT OUTER JOIN item_stock_master
            ON item_master.item_id = item_stock_master.item_id
            ORDER BY item_id asc'; 
            //今回WHEREなし。
    // クエリ実行(関数にこのSQL文を渡す。)
    $data = get_as_array($dbh, $sql);
}catch(PDOException $e){
    //throw $e;
    //echo '接続できませんでした。理由：'.$e->getMessage();
    $err_msg[] = '接続できませんでした。理由：'.$e->getMessage();
}
//表示順はSELECT文中にasc/desc。
//var_dump($data);

//エンティティ化
$data = ent2($data);


//表示ファイル読み込み
//ログインしていない場合はログインログインページへ。してても管理者でない場合はindexへ。

// セッション開始
session_start();
$username = $_SESSION['user_name'];

if (!isset($_SESSION['user_name'])) {
    header('Location:./login.php');
    exit;
}elseif($username !== 'admin00'){
    header('Location:./index.php');
    exit;
}
    include_once './view/view_item_tool.php';

//$dbh=NULL;
 
 
//書かない                    // // リロード対策でリダイレクト
                    // header('Location: http://'. $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    // exit;
             