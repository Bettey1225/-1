<?php
// 設定ファイル読み込み
require_once './conf/const.php';
// 関数ファイル読み込み
require_once './model/function.php';


//変数初期化 
$date = date('Y-m-d H:i:s');
$data = array();
$err_msg = array();
$img_dir    = './uploadimg/';
$result_msg = '';
$sql_kind   = '';       //画面内でクリックした送信ボタンに応じて処理を振り分けるため
$result = '';
//$resultarray = array();
$rows = array();
$tmp = '';
//エラーチェックなどはresultで行う。
//常に実行する処理 
//データベースに接続し、すでに登録されている内容をSELECTで参照。
try{
    $dbh = get_db_connect();
    //SQL生成
    $sql = 'SELECT 
            item_master.item_id,
            item_master.item_name,
            item_master.price,
            item_master.img,
            item_master.status,
            item_stock_master.stock
            FROM item_master LEFT OUTER JOIN item_stock_master
            ON item_master.item_id = item_stock_master.item_id
            ORDER BY item_id asc'; 
            //今回WHEREなし。
    // クエリ実行(関数にこのSQL文を渡す。)
    $data = get_as_array($dbh, $sql);
}catch(PDOException $e){
    //throw $e;
    $err_msg[] = '接続できませんでした。理由：'.$e->getMessage();
}
//表示順はSELECT文中にasc/desc。
//var_dump($data);

//エンティティ化
$data = ent2($data);

//表示ファイル読み込み
 
session_start();

if (isset($_SESSION['user_name'])) {
$username = $_SESSION['user_name'];
}else{
    header('Location:./login.php');
    exit;
}
include_once './view/view_item_list.php';
 
