<!DOCTYPE HTML>
<html lang ="ja">
<head>
    <meta charset ="UTF-8">
    <title>WhiskeyRestation_top</title>
    <!--<link rel="canonical" href="正規化するURL">-->
    <!--view単体テスト時は単体テスト時は../だけどindex.phpから動かすときは./-->
        <link rel="stylesheet" href="./css/reset.css">
        <link rel="stylesheet" href="./css/header_footer.css">
<!--        <link rel="stylesheet" href="./css/login.css">-->
    <link rel="icon" href="./img/fab.jpg" sizes="18x18" type="image/jpg">
    <link href="https://fonts.googleapis.com/css?family=Noto+Serif+JP" rel="stylesheet">
</head>
<header>
    <div class="header_flex">       
        <!--ロゴ-->
        <a href="#"><img class="logo" src="./img/logo.png" alt="Whiskey_Restation"></a>
        
        <div>
<!--        <p class="name"><small class="font">こんにちは<?php print $username ?>さん</small></p>-->

        <ul class="header_ul">
            <li class="header_li"><a class="font_li"></a></li>
            <li class="header_li"><a class="font_li" href="../about.php">About</a></li>
            <li class="header_li"><a class="font_li">Company</a></li>
            <li class="header_li"><a class="font_li">Shoplist</a></li>
            <li class="header_li"><a class="font_li">Infomation</a></li>
            <li class="header_li"><a class="font_li">Support</a></li>
            <li class="header_li"><a class="font_li" href="#">Login/out</a></li>
        </ul>
        </div>
            <!--ログイン画面へ-->
        <!--<p><a href="#" ><img class="headericon" src="./img/key.png" alt="ログイン" ></a></p>-->
            <!--カートページへ-->
        <!--<p><a href="#" ><img class="headericon" src="./img/cart.png" alt="カート"></a></p>-->
    </div>
</header>

<body>

    <main>
    <?php if(count($err_msg) > 0){?>
        <ul>
            <?php foreach($err_msg as $val){ ?>
            <li><?php print $val; ?></li>
            <?php } ?>
        </ul>
    <?php } ?>
    <table>
        <form method="post" action="login.php">
        <tr>
            <th>ユーザー名：</th>
            <td><input type="text" name="check_username" value=""></td>
        </tr>
        <tr>
            <th>パスワード：</th>
            <td><input type="password" name="check_password" value=""></td>
        </tr>
    </table> 
        <input class="loginbutton" type="submit" value="ログイン">
        <input type="hidden" name="sql_kind" value="login">
        </form>
    <!--<p>共に半角英数字6文字以上です。</p>-->
<!--        <p class="login"><a href="./view/view_index.php">ログイン</a></p>-->
    <div class="lower">   
        <br>
        <p><small>ユーザー名、パスワードをお忘れの方は<a href="#">こちら</a>からお問い合わせください。</small></p>
        <p>アカウント新規作成は<a href="./view/view_newaccount.php">こちら</a>から。</p>
    </div>    
    
    </main>

<footer>
    <div class="footer_left">
        <p><small class="font">株式会社XXXXXXXX&nbsp;&nbsp;TEL:0123-45-6789</small></p>
        <p><small class="font">大阪府大阪市北区梅田xx-x-x</small></p>
        <p><small class="font">&copy; Whiskey Restation All Rights Reserved.</small></p>
    </div>
    
    <div class="footer_center  font">
        <p class="font">xxxxxxxxxご利用ガイドxxxxxxx</p>
    </div>
    <div class="footer_right">
        <img src="./img/icon_f.png" alt="sns_icon1">
        <img src="./img/icon_t.png" alt="sns_icon2">
        <img src="./img/icon_i.png" alt="sns_icon3">
    </div>    
</footer>  
</body>
</html>
  