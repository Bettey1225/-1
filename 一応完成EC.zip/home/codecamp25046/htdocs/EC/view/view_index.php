<!DOCTYPE HTML>
<html lang ="ja">
<head>
    <meta charset ="UTF-8">
    <title>WhiskeyRestation_top</title>
    <!--<link rel="canonical" href="正規化するURL">-->
    <!--view単体テスト時は単体テスト時は../だけどindex.phpから動かすときは./-->
    <link rel="stylesheet" href="./css/reset.css">
    <link rel="stylesheet" href="./css/index.css">
    <link rel="icon" href="../img/fab.jpg" sizes="18x18" type="image/jpg">
    <link href="https://fonts.googleapis.com/css?family=Noto+Serif+JP" rel="stylesheet">
</head>
<body>
    <header>
    <div class="header_flex">       
        <!--ロゴ-->
        <a href="./index.php"><img class="logo" src="./img/logo.png" alt="Whiskey_Restation"></a>
        
        <div>
        <p class="name"><small class="font">こんにちは<?php print $username ?>さん</small></p>

        <ul class="header_ul">
            <li class="header_li"><a class="font_li"></a></li>
            <li class="header_li"><a class="font_li" href="./about.php">About</a></li>
            <li class="header_li"><a class="font_li">Company</a></li>
            <li class="header_li"><a class="font_li">Shoplist</a></li>
            <li class="header_li"><a class="font_li">Infomation</a></li>
            <li class="header_li"><a class="font_li">Support</a></li>
            <li class="header_li"><a class="font_li" href="./logout.php">Login/out</a></li>
        </ul>
        </div>
            <!--ログイン画面へ-->
        <p><a href="./logout.php" ><img class="headericon" src="./img/key.png" alt="ログイン" ></a></p>
            <!--カートページへ-->
        <p><a href="./cart.php" ><img class="headericon" src="./img/cart.png" alt="カート"></a></p>
    </div>
    <div class="position">
    <img id="slide"class="eyecatch" src="./img/eyecatch.jpg">
    <!--<img id="slide2"class="eyecatch4" src="../img/eyecatch.jpg">-->
    
            <!--5000ミリ秒＝5秒で次の画像に切り替わる。ifnum==は配列が0からなので3枚なら2の時の時0に戻るように-->
            <script>
            var pics_src = new Array("./img/eyecatch.jpg","./img/eyecatch9.jpg","./img/eyecatch6.jpg","./img/eyecatch7.jpg","./img/eyecatch3.jpg");
            var num = -1;
            var myflg = 0;		//どっちを表示して、どっちを消すかのフラグ
            slideshow_timer();
                function slideshow_timer(){
                    // myNowCnt = (myNowCnt<myImage.length-1) ? myNowCnt+1 : 0;// 次の配列番号
                    // myflg = (myflg==0) ? 1 : 0; // 表示・非表示フラグ反転
                    // if (myflg == 0){
                    //     document.getElementById("slide1").src = pics_src[myNowCnt];
                    //     // 次の画像をセットする
                    //     document.getElementById("slide1").className = "fadein";
                    //     // フェードイン
                    //     document.getElementById("slide2").className = "fadeout";
                    //     // フェードアウト
                    //     }else{
                    //     document.getElementById("slide2").src = pics_src[myNowCnt];
                    //     // 次の画像をセットする
                    //     document.getElementById("slide1").className = "fadeout";
                    //     // フェードアウト
                    //     document.getElementById("slide2").className = "fadein";
                    //     // フェードイン
                    // }
                    
                    if (num == 4){
                        num = 0;
                    }else{
                        num ++;
                    }
                    document.getElementById("slide").src=pics_src[num];
                    setTimeout("slideshow_timer()",8000); 
                }
            </script>
    
    
    <p class="white font">CATCHPHLASEXXXXXXXXXX<br>XXXXXXXXXXXXXXXXXXXX</p>
    </div>
    
    </header>

    <main>
<!--ワード検索機能未実装,カテゴリ検索も-->
        <nav>
        <form method="post" enctype="multipart/form-data" action="item_list.php">
        <div class="searchflex">
            <input class="searchbox" type="text" name="search" value="" placeholder="検索キーワード">
            <input type="hidden" name="search_word" value="" >
            <input class="searchicon" type="submit" value="" style="background:url('./img/search.png');width:35px;height:23px;border:1px">
        </div>
        <!--        <input type="hidden" name="sql_kind" value="insert">
        -->

        </form>
          <ul>
            <li><a class="a_side font" href="./item_list.php">全商品一覧</a></li>
            <li><a class="a_side font" href="#">産地で選ぶ</a></li>
            <li><a class="a_side font" href="#">予算で選ぶ</a></li>
            <li><a class="a_side font" href="#">ウイスキー</a></li>
            <li><a class="a_side font" href="#">ラム、ブランデー<br>リキュール</a></li>
            <li><a class="a_side font" href="#">おつまみ</a></li>
            <li><a class="a_side font" href="#">その他</a></li>
          </ul>
        </nav>
        

    <!--センター-->

        <section class="center">
        <p class="font_center subtitle">イベント情報</p>
        
        <div class="event_flex">    
            <div class="event1">
            <a href="#"><img class="event_img" src="./img/event2.jpg" alt="イベント情報1"></a>    
            <p class="event_font">キリンのウイスキー「富士山麓」の期間限定イベント<br>
            「Experience Bar」6/30まで！</p>
            </div>
            <div class="event2">
            <a href="#"><img class="event_img" src="./img/event.jpg" alt="イベント情報2"></a>    
            <p class="event_font"><br>国内最大規模のウイスキーイベントが、パワーアップして今年も開催！<br>
            「Whisky Festival」東京/大阪</p>    
            </div>
        </div>
        
        <p class="font_center subtitle">ショップNEWS</p>
            <div class="news1">
            <a href="#"><img class="news_img" src="./img/event0.jpg" alt="ショップ情報1"></a>    
                <div class="news_block">
                <p class="news_font">どんなウイスキーが好きかわからない。<br>
                いきなりボトル1本はちょっと高いし…<br>
                失敗したらどうしよう。</p>
                <p class="news_font2">そんなあなたにウイスキーをお試しできる場を提供します。</p>
                </div>
            </div>


        <p class="font_center subtitle">おすすめ商品</p>
<!--あとでflg立てたのが出るようにしたい-->
        <div class="rec_flex">    
            <div class="event1">
            <a href="#"><img class="event_img" src="./img/begin.jpg" alt="商品情報1"></a>    
            <p class="event_font">ウイスキーミニボトル&nbsp;飲み比べセット<br>
            5種&nbsp;1500円</p>
            </div>
            <div class="event2">
            <a href="#"><img class="event_img" src="./img/item_macallan12.jpg" alt="商品情報2"></a>    
            <p class="event_font">ザ・マッカラン&nbsp;12年<br>
             700ml&nbsp;6720円</p>    
            </div>
        </div>
        


        </section>
        
    <!--右サイド-->
    <aside>
        <ul>
            <li><a class="a_side font" href="#">ウイスキーの基礎知識</a></li>
            <li><a class="a_side font" href="#">ハイボールをおいしく飲むコツ</a></li>
            <li><a class="a_side font" href="#">カクテル紹介</a></li>
            <li><a class="a_side font" href="#">お手軽<br>おつまみレシピ</a></li>
            <li><a class="a_side font" href="#">試飲会情報</a></li>
        </ul>
        <!--イベント広告画像など-->
        <p class="aside_font">4月8日から470本を日本限定発売！<br>
        『ザ・グレンリベット シングルカスク2019』</p>
        <a href="./new_event.html"><img class="side_new" src="./img/new_glenlivet2019.jpg" alt="イベントや新商品"></a>
    </aside>
    </main>
    
        
        
        
        
    <footer>
        <div class="footer_left">
            <p><small class="font">株式会社XXXXXXXX&nbsp;&nbsp;TEL:0123-45-6789</small></p>
            <p><small class="font">大阪府大阪市北区梅田xx-x-x</small></p>
            <p><small class="font">&copy; Whiskey Restation All Rights Reserved.</small></p>
        </div>
        
        <div class="footer_center  font">
            <p class="font">xxxxxxxxxご利用ガイドxxxxxxx</p>
        </div>
        <div class="footer_right">
            <img src="./img/icon_f.png" alt="sns_icon1">
            <img src="./img/icon_t.png" alt="sns_icon2">
            <img src="./img/icon_i.png" alt="sns_icon3">
        </div>    
    </footer>  
</body>

</html>
  