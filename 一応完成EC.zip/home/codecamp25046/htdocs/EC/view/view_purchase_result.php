<!DOCTYPE HTML>
<html lang ="ja">
    <head>
        <meta charset ="UTF-8">
        <title>購入結果</title>
        <link rel="stylesheet" href="./css/reset.css">
        <link rel="stylesheet" href="./css/header_footer.css">
        <link rel="stylesheet" href="./css/purchase_result.css">
    </head>
    <header>
    <div class="header_flex">       
        <!--ロゴ-->
        <a href="./index.php"><img class="logo" src="./img/logo.png" alt="Whiskey_Restation"></a>
        
        <div>
        <p class="name"><small class="font">こんにちは<?php print $username ?>さん</small></p>

        <ul class="header_ul">
            <li class="header_li"><a class="font_li"></a></li>
            <li class="header_li"><a class="font_li" href="./about.php">About</a></li>
            <li class="header_li"><a class="font_li">Company</a></li>
            <li class="header_li"><a class="font_li">Shoplist</a></li>
            <li class="header_li"><a class="font_li">Infomation</a></li>
            <li class="header_li"><a class="font_li">Support</a></li>
            <li class="header_li"><a class="font_li" href="./logout.php">Login/out</a></li>
        </ul>
        </div>
            <!--ログイン画面へ-->
        <p><a href="./logout.php" ><img class="headericon" src="./img/key.png" alt="ログイン" ></a></p>
            <!--カートページへ-->
        <p><a href="./cart.php" ><img class="headericon" src="./img/cart.png" alt="カート"></a></p>
    </div>
    </header>
    
    <body>
    <p class="font_center subtitle">購入結果</p>
    
    <p><?php print $result_msg; ?></p>
    <!--エラー内容表示 配列errors,要素errorで書く？-->
    <?php if(count($err_msg) > 0){?>
    <ul>
        <?php foreach($err_msg as $val){ ?>
        <li><?php print $val; ?></li>
        <?php } ?>
    </ul>
<?php //print $data[0];
//exit; ?>

    <?php } else { ?>
<?php if($itemamount !== ''){ ?>
    <p class="font_amount">お買い上げありがとうございます。</p>
    <p class="font_amount">合計&nbsp;<?php print $moneyamount; ?>円です。</p>
    <br>
    <p class="to_itemlist"><a class="to_itemlist_a" href="./item_list.php">商品一覧へ</a></p>
<?php } ?>
    <!--内容を表形式で表示  ここでは非公開状態の商品も表示、在庫切れと合わせて購入時にチェック。-->

<table>
    <tr>
        <th>商品画像</th>
        <th>商品名</th>
        <th>内容量</th>
        <th>価格</th>
        <th>購入数量</th>
    </tr>
    <!--内容を表形式で表示-->
    <?php foreach($cartdata as $val){ ?>
    <!--php foreach($cartdata as $v){ -->
    <!--php if ($val['status'] === '1') { -->
    <tr>
    <!--php } else { -->
    <!--        <tr style="background-color:#C0C0C0">-->
    <!--php } -->
    
            <td><img class="itemimg" src="<?php print $img_dir .$val['img']; ?>"></td>
            <td><?php print $val['item_name']; ?></td>
            <td><?php print $val['net_volume']; ?></td>
            <td align="right"><?php print separate($val['price']); ?></td>
            <td><?php print $val['amount']; ?></td>
    </tr>
    <?php } ?>
    <!--php } -->
</table>


  
    <?php } ?>
    <!--コントローラーの位置にあるのでカレントディレクトリでカレントディレクトリでOK-->
   <p class="to_itemlist"><a class="to_itemlist_a" href="./item_list.php">商品購入ページへ戻る</a></p>
</body>
<footer>
    <div class="footer_left">
        <p><small class="font">株式会社XXXXXXXX&nbsp;&nbsp;TEL:0123-45-6789</small></p>
        <p><small class="font">大阪府大阪市北区梅田xx-x-x</small></p>
        <p><small class="font">&copy; Whiskey Restation All Rights Reserved.</small></p>
    </div>
    
    <div class="footer_center  font">
        <p class="font">xxxxxxxxxご利用ガイドxxxxxxx</p>
    </div>
    <div class="footer_right">
        <img src="./img/icon_f.png" alt="sns_icon1">
        <img src="./img/icon_t.png" alt="sns_icon2">
        <img src="./img/icon_i.png" alt="sns_icon3">
    </div>    
</footer>  
</html>