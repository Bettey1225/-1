<!DOCTYPE HTML>
<html lang ="ja">
<head>
    <meta charset ="UTF-8">
    <title>WhiskeyRestation_top</title>
    <!--<link rel="canonical" href="正規化するURL">-->
        <link rel="stylesheet" href="../css/reset.css">
        <link rel="stylesheet" href="../css/header_footer.css">
<!--        <link rel="stylesheet" href="./css/newaccount.css">-->
    <link rel="icon" href="../img/fab.jpg" sizes="18x18" type="image/jpg">
    <link href="https://fonts.googleapis.com/css?family=Noto+Serif+JP" rel="stylesheet">
</head>
<header>
    <div>        
        <!--ロゴ-->
        <a href="#"><img class="logo" src="../img/logo.png" alt="Whiskey_Restation"></a>
        <ul class="header_ul">
            <li class="header_li"><a class="font_li"></a></li>
            <li class="header_li"><a class="font_li" href="../about.html">About</a></li>
            <li class="header_li"><a class="font_li">Company</a></li>
            <li class="header_li"><a class="font_li">Shoplist</a></li>
            <li class="header_li"><a class="font_li">Infomation</a></li>
            <li class="header_li"><a class="font_li">Support</a></li>
            <li class="header_li"><a class="font_li" href="#">Login/out</a></li>
        </ul>
        <div class="username">
            <?php
            if (isset($_SESSION['user_name'])) {
                $username = $_SESSION['user_name'];?>
            <p><small class="font">こんにちは<?php print $username ?>さん</small></p>
            <?php } ?>
        </div>
            <!--ログイン画面へ-->
        <p><a href="#" ><img class="headericon" src="../img/key.png" alt="ログイン" ></a></p>
            <!--カートページへ-->
        <p><a href="#" ><img class="headericon" src="../img/cart.png" alt="カート"></a></p>
    </div>
</header>
<body>

    <main>
    <!--<p><?php print $result_msg; ?></p>-->
    <!--エラー内容表示 配列errors,要素errorで書く？-->
    <?php if(count($err_msg) > 0){?>
    <ul>
        <?php foreach($err_msg as $val){ ?>
        <li><?php print $val; ?></li>
        <?php } ?>
    </ul>
    <?php } ?>
    
        <p class="new_title">新規登録</p>
        
    <table>
    <form method="post" action="../user_tool.php">
    <!--<form method="post" action="login.php">-->
        <tr>
            <th>お名前:</th>
            <td><input type="text" name="input_name" value=""></td>
        </tr>
        <tr>
            <th>ユーザー名:</th>
            <td><input type="text" name="input_username" value="">
            <p><small>※ユーザー名は半角英数字かつ6文字以上で入力してください。</small></p></td>
        </tr>
        <tr>
            <th>パスワード：</th>
            <td><input type="password" name="input_password" value="">
            <p><small>※パスワードは半角英数字かつ6文字以上で入力してください。</small></p></td>
        </tr>
        <tr>
            <th>mail：</th>
            <td><input type="text" name="input_mail" value=""></td>
        </tr>
        <tr>
            <th>TEL(-あり)：</th>
            <td><input type="text" name="input_tel" value=""></td>
        </tr>
        <tr>
            <th>生年月日：</th>
            <td><input type="text" name="input_birthdate" value="" placeholder="yyyy-mm-dd"></td>
        </tr>           
        <tr>
            <th>性別：</th>
            <td><input type="radio" name="input_sex" value="1">男性
                <input type="radio" name="input_sex" value="2">女性</td>
        </tr>
        <tr>
            <th>郵便番号：</th>
            <td><input type="text" name="input_postalcode" value="" placeholder="000-0000"></td>
        </tr>        
                <tr>
            <th>住所：</th>
            <td><input type="text" name="input_address" value=""></td>
        </tr>  
        
    </table> 
        <div class="newuser">
        <input type="submit" value="■新規登録■">
        <input type="hidden" name="sql_kind" value="insert">
        <select name="visible_status">
            <!--<option value="0">非公開</option>-->
            <option value="1">登録</option>
        </select>
        </div>
    </form>
    <!--新規追加時はupdatetime入れない-->    

   
   
        
    <!--ユーザー情報の変更(ユーザーが)は未実装-->    
   
   
   
        
    </main>
</body>
<footer>
    <div class="footer_left">
        <p><small class="font">株式会社XXXXXXXX&nbsp;&nbsp;TEL:0123-45-6789</small></p>
        <p><small class="font">大阪府大阪市北区梅田xx-x-x</small></p>
        <p><small class="font">&copy; Whiskey Restation All Rights Reserved.</small></p>
    </div>
    
    <div class="footer_center  font">
        <p class="font">xxxxxxxxxご利用ガイドxxxxxxx</p>
    </div>
    <div class="footer_right">
        <img src="../img/icon_f.png" alt="sns_icon1">
        <img src="../img/icon_t.png" alt="sns_icon2">
        <img src="../img/icon_i.png" alt="sns_icon3">
    </div>    
</footer>  
</html>
  