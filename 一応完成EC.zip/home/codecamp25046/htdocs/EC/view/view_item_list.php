<!DOCTYPE HTML>
<html lang ="ja">
    <head>
        <meta charset ="UTF-8">
        <title>商品購入ページ</title>
        <link rel="stylesheet" href="./css/reset.css">
        <link rel="stylesheet" href="./css/header_footer.css">
        <link rel="stylesheet" href="./css/item_list.css">
        <link rel="icon" href="../img/fab.jpg" sizes="18x18" type="image/jpg">
        <link href="https://fonts.googleapis.com/css?family=Noto+Serif+JP" rel="stylesheet">
        
    <!--上に戻る用-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
    <script>
    jQuery(document).ready(function() {
    var offset = 100;
    var duration = 500;
    jQuery(window).scroll(function() {
    if (jQuery(this).scrollTop() > offset) {
    jQuery('.pagetop').fadeIn(duration);
    } else {
    jQuery('.pagetop').fadeOut(duration);
    }
    });
    
    jQuery('.pagetop').click(function(event) {
    event.preventDefault();
    jQuery('html, body').animate({scrollTop: 0}, duration);
    return false;
    })
    });
    </script>    
        
    </head>
    <header>
    <div class="header_flex">       
        <!--ロゴ-->
        <a href="./index.php"><img class="logo" src="./img/logo.png" alt="Whiskey_Restation"></a>
        
        <div>
        <p class="name"><small class="font">こんにちは<?php print $username ?>さん</small></p>

        <ul class="header_ul">
            <li class="header_li"><a class="font_li"></a></li>
            <li class="header_li"><a class="font_li" href="./about.php">About</a></li>
            <li class="header_li"><a class="font_li">Company</a></li>
            <li class="header_li"><a class="font_li">Shoplist</a></li>
            <li class="header_li"><a class="font_li">Infomation</a></li>
            <li class="header_li"><a class="font_li">Support</a></li>
            <li class="header_li"><a class="font_li" href="./logout.php">Login/out</a></li>
        </ul>
        </div>
            <!--ログイン画面へ-->
        <p><a href="./logout.php" ><img class="headericon" src="./img/key.png" alt="ログイン" ></a></p>
            <!--カートページへ-->
        <p><a href="./cart.php" ><img class="headericon" src="./img/cart.png" alt="カート"></a></p>
    </div>
    <script>
    //GET値にx,y座標を渡し、リロード後にスクロールする
        // リロード TODO: ?が無い場合対応
        function keep_scroll_reload() {
                var re = /&page_x=(\d+)&page_y=(\d+)/;
                var page_x = document.documentElement ? document.documentElement.scrollLeft : document.body.scrollLeft;
                var page_y = document.documentElement ? document.documentElement.scrollTop : document.body.scrollTop;
                var position = '&page_x=' + page_x + '&page_y=' + page_y;
                if(!url.match(re)) {
                //初回
                location.href = url + position;
                } else {    
                location.href = url.replace(/&page_x=(\d+)&page_y=(\d+)/,position);
                }
        }
    
    // スクロール位置を復元
        function restore_scroll() {
                var re = /&page_x=(\d+)&page_y=(\d+)/;
                if(window.location.href.match(re)) {
                        var position = window.location.href.match(re)
                        window.scrollTo(position[1],position[2]);
                }
        }
        
    (window.onload = function() {
            restore_scroll();
    })();
    </script>
    </header>
    
    <body>
<!--    <h1>商品購入ページ</h1>-->

    <!--エラー内容表示 配列errors,要素errorで書く？-->
    <?php if(count($err_msg) > 0){?>
    <ul>
        <?php foreach($err_msg as $val){ ?>
        <li><?php print $val; ?></li>
        <?php } ?>
    </ul>
    <?php } ?>

<main>
    <section>
    <p class="font_center subtitle">おすすめ</p>
<!--本来はフラグ付いた商品を出す。-->    
        <div class="rec_flex">    
            <div class="rec1">
            <a href="#"><img class="rec_img" src="./img/begin.jpg" alt="商品情報1"></a>    
            <p class="rec_font">ウイスキーミニボトル&nbsp;飲み比べセット<br>
            5種&nbsp;1500円</p>
            </div>
            <div class="rec2">
            <a href="#"><img class="rec_img" src="./img/item_macallan12.jpg" alt="商品情報2"></a>    
            <p class="rec_font">ザ・マッカラン&nbsp;12年<br>
             700ml&nbsp;6720円</p>    
            </div>
            <div class="rec3">
            <a href="#"><img class="rec_img" src="./img/item_白州.jpg" alt="商品情報3"></a>    
            <p class="rec_font">白州&nbsp;<br>
             700ml&nbsp;7100円</p>    
            </div>
        </div>
    
    
    </section>
<!--検索機能未実装-->    
    <section>
    <p class="font_center subtitle">検索条件(未)</p>    
    
    <div class="searchbox">    
        <label class="font_search">カテゴリ1</label><select name="category1">
            <option value="1">お酒</option>
            <option value="2">食べ物</option>
            <option value="3">その他</option>
            <option value="99">絞込なし</option>
        </select>
        <label class="font_search">カテゴリ2</label><select name="category2">
            <option value="1">ウイスキー</option>
            <option value="2">ラム</option>
            <option value="3">ブランデー</option>
            <option value="101">おつまみ<option>
            <option value="999">その他</option>
            <option value="99">絞込なし</option>
        </select>
        <label class="font_search">産地</label><select name="category3">
            <option value="1">日本</option>
            <option value="2">イギリス(アイラ)</option>
            <option value="3">イギリス(スペイサイド)</option>
            <option value="6">イギリス(その他)<option>
            <option value="7">アメリカ</option>
            <option value="8">カナダ</option>
            <option value="999">その他<option>            
            <option value="99">絞込なし</option>
        </select>
        <label class="font_search">並び順</label><select name="col">
            <option value="1">新着順</option>
            <option value="2">カテゴリ順</option>
            <option value="3">人気順</option>
        </select>
        <br>
        <label class="font_search keybox">キーワード:</label><input type="text" name="keyword" value="">
        
        <input type="submit" value="検索">
        <input type="hidden" name="sql_kind" value="search">
    </div>
    </section>    
    
    <!--★あとで商品詳細ページを作る-。パンくずも。->
    <!--返す先はitem_list.phpでなくresult(コントロール)へ。-->
<!--<form method="post" action="purchase_result.php">-->

        <!--<div><label>金額:<input type="text" name="money" value=""></label></div>-->
        <!--<div><input type="hidden" name="err_file" value="選択されていません" ></div>-->
        <!--<input type="submit" value="■購入■">-->
        <!--<input type="hidden" name="sql_kind" value="purchase">-->

    <p class="font_center subtitle">商品一覧</p>  

<table>
    <!--内容を表形式で表示  今回は非公開状態の商品は表示させない、在庫切れはラジオボタンなしで表示。-->
    <?php $i=0; ?>
    <?php foreach($data as $val){ ?>
<form method="post" action="cart.php">
    <?php if ($val['status'] === '1') { ?>
        <!--<tr class="item_row">-->
    <div class="block-group item_row">
    <?php if($i%3 === 0){
        print '<tr class="box1">';
    } ?>
            <td>
                <img class="itemimg" src="<?php print $img_dir.$val['img']; ?>">
                <p class="item_font">■<?php print $val[1]; ?></p>
                <p class="item_font"><?php print separate($val[2]); ?>円</p>
                <p class="item_font">残り<?php print $val['stock']; ?>個
                <?php if($val['stock']>0){ ?>
                
                    <input class="inputbutton" type="submit" value="■カートへ■">
                    <input type="hidden" name="sql_kind" value="to_cart">
                    <input type="hidden" name="item_id" value="<?php print $val['item_id']; ?>">
                
                <?php } else { ?>
                <span  class="red">売り切れ<span>
                <?php } ?>
                </p>
                <br><br>
            </td>

    <?php if($i%3 === 2 || $i === count($data)-1){
        print '</tr>';
    } ?>
    
    </div>            
        <!--</tr>-->
    <?php $i++; } ?>
</form>
    <?php } ?>
</table>


<div class="pagetop">上へ</div>
</main>
</body>
</html>
<footer>
    <div class="footer_left">
        <p><small class="font">株式会社XXXXXXXX&nbsp;&nbsp;TEL:0123-45-6789</small></p>
        <p><small class="font">大阪府大阪市北区梅田xx-x-x</small></p>
        <p><small class="font">&copy; Whiskey Restation All Rights Reserved.</small></p>
    </div>
    
    <div class="footer_center  font">
        <p class="font">xxxxxxxxxご利用ガイドxxxxxxx</p>
    </div>
    <div class="footer_right">
        <img src="./img/icon_f.png" alt="sns_icon1">
        <img src="./img/icon_t.png" alt="sns_icon2">
        <img src="./img/icon_i.png" alt="sns_icon3">
    </div>    
</footer>  