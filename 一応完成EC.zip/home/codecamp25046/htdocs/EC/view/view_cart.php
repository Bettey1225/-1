<!DOCTYPE HTML>
<html lang ="ja">
    <head>
        <meta charset ="UTF-8">
        <title>商品購入ページ</title>
        <link rel="stylesheet" href="./css/reset.css">
        <link rel="stylesheet" href="./css/header_footer.css">
        <link rel="stylesheet" href="./css/cart.css">
        <link rel="icon" href="../img/fab.jpg" sizes="18x18" type="image/jpg">
        <link href="https://fonts.googleapis.com/css?family=Noto+Serif+JP" rel="stylesheet">
        
    <!--上に戻る用-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
    <script>
    jQuery(document).ready(function() {
    var offset = 100;
    var duration = 500;
    jQuery(window).scroll(function() {
    if (jQuery(this).scrollTop() > offset) {
    jQuery('.pagetop').fadeIn(duration);
    } else {
    jQuery('.pagetop').fadeOut(duration);
    }
    });
    
    jQuery('.pagetop').click(function(event) {
    event.preventDefault();
    jQuery('html, body').animate({scrollTop: 0}, duration);
    return false;
    })
    });
    </script>    
        
    </head>
    <header>
    <div class="header_flex">       
        <!--ロゴ-->
        <a href="./index.php"><img class="logo" src="./img/logo.png" alt="Whiskey_Restation"></a>
        
        <div>
        <p class="name"><small class="font">こんにちは<?php print $username ?>さん</small></p>

        <ul class="header_ul">
            <li class="header_li"><a class="font_li"></a></li>
            <li class="header_li"><a class="font_li" href="./about.php">About</a></li>
            <li class="header_li"><a class="font_li">Company</a></li>
            <li class="header_li"><a class="font_li">Shoplist</a></li>
            <li class="header_li"><a class="font_li">Infomation</a></li>
            <li class="header_li"><a class="font_li">Support</a></li>
            <li class="header_li"><a class="font_li" href="./logout.php">Login/out</a></li>
        </ul>
        </div>
            <!--ログイン画面へ-->
        <p><a href="./logout.php" ><img class="headericon" src="./img/key.png" alt="ログイン" ></a></p>
            <!--カートページへ。GETで送信されるのでエラーが出る-->
        <p><a href="./cart.php" ><img class="headericon" src="./img/cart.png" alt="カート"></a></p>
        <!--<form method="post" action="./cart.php">-->
        <!--<input type="image" src="./img/cart.png" alt="カート">-->
        <!--</form>-->
    </div>
    <script>
    //GET値にx,y座標を渡し、リロード後にスクロールする
        // リロード TODO: ?が無い場合対応
        function keep_scroll_reload() {
                var re = /&page_x=(\d+)&page_y=(\d+)/;
                var page_x = document.documentElement ? document.documentElement.scrollLeft : document.body.scrollLeft;
                var page_y = document.documentElement ? document.documentElement.scrollTop : document.body.scrollTop;
                var position = '&page_x=' + page_x + '&page_y=' + page_y;
                if(!url.match(re)) {
                //初回
                location.href = url + position;
                } else {    
                location.href = url.replace(/&page_x=(\d+)&page_y=(\d+)/,position);
                }
        }
    // スクロール位置を復元
        function restore_scroll() {
                var re = /&page_x=(\d+)&page_y=(\d+)/;
                if(window.location.href.match(re)) {
                        var position = window.location.href.match(re)
                        window.scrollTo(position[1],position[2]);
                }
        }
        
    (window.onload = function() {
            restore_scroll();
    })();
    </script>
    </header>
    
    <body>
<!--    <h1>商品購入ページ</h1>-->

    <!--エラー内容表示 配列errors,要素errorで書く？-->
    <?php if(count($err_msg) > 0){?>
    <ul>
        <?php foreach($err_msg as $val){ ?>
        <li><?php print $val; ?></li>
        <?php } ?>
    </ul>
    <?php } ?>

<main>

    <!--商品一覧ページへ-->
    <p class="to_itemlist"><a class="to_itemlist_a" href="./item_list.php">買い物を続ける</a></p>

<div class="flex_purchase">        
    <!--返す先はresult(コントロール)へ。-->
<form method="post" action="purchase_result.php">
        <input class="purchasebutton" type="submit" value="■購入■">
        <input type="hidden" name="sql_kind" value="purchase">
</form>
    <!--ログインユーザーの購入履歴を見る-->
<form method="post" action="being_prepared.html">
        <input class="purchase_history" type="submit" value="購入履歴を見る">
        <input type="hidden" name="sql_kind" value="purchase_history">
</form>
</div>

    <p class="font_center subtitle">カート内商品一覧</p>  
<br>
<?php if($itemamount !== ''){ ?>
    <p  class="font_amount">計&nbsp;<?php print $itemamount; ?>個、<?php print $moneyamount; ?>円です。</p>
<?php } ?>
    <!--内容を表形式で表示  ここでは非公開状態の商品も表示、在庫切れと合わせて購入時にチェック。-->
<table>
    <tr>
        <th>商品画像</th>
        <th>商品名</th>
        <th>内容量</th>
        <th>価格</th>
        <th>購入数量</th>
        <th>数量変更</th>
        <th>削除</th>
        <th>在庫数量</th>
    </tr>
    <!--内容を表形式で表示-->
    <?php foreach($data as $val){ ?>
    <!--php foreach($cartdata as $v){ -->
    <!--php if ($val['status'] === '1') { -->
    <tr>
    <!--php } else { -->
    <!--        <tr style="background-color:#C0C0C0">-->
    <!--php } -->
     
            <td><img class="itemimg" src="<?php print $img_dir . $val['img']; ?>"></td>
            <td><?php print $val['item_name']; ?></td>
            <td><?php print $val['net_volume']; ?></td>
            <td align="right"><?php print separate($val['price']); ?></td>
    
        <form method="post" action="cart.php">
            <td><input type="text"  name="update_amount" value="<?php print $val['amount']; ?>" size="5"></td>
            <td><input type="submit" value="変更"></td>
            <input type="hidden" name="sql_kind" value="update_amount">
            <input type="hidden" name="cart_id" value="<?php print $val['cart_id']; ?>">
            <input type="hidden" name="item_id" value="<?php print $val['item_id']; ?>">
        </form>
        <form method="post" action="cart.php">
            <td><input type="submit" value="削除"></td>
            <input type="hidden" name="sql_kind" value="delete_cartrow">
            <input type="hidden" name="cart_id" value="<?php print $val['cart_id']; ?>">
        </form>
        <td><?php print $val['stock']; ?></td>
    </tr>
    <?php } ?>
    <!--php } -->
</table>
<form method="post" action="purchase_result.php">    
    <input class="purchasebutton" type="submit" value="■購入■">
    <input type="hidden" name="sql_kind" value="purchase">
</form>    


    <section>
    <p class="">こちらもいかがでしょうか</p>
<!--本来はフラグ付いた商品を出す。-->    
        <div class="rec_flex">    
            <div class="rec1">
            <a href="#"><img class="rec_img" src="./img/begin.jpg" alt="商品情報1"></a>    
            <p class="rec_font">ウイスキーミニボトル&nbsp;飲み比べセット<br>
            5種&nbsp;1500円</p>
            </div>
            <div class="rec2">
            <a href="#"><img class="rec_img" src="./img/ドライフルーツ.jpg" alt="商品情報2"></a>    
            <p class="rec_font">ドライフルーツ mix&nbsp;(5種)<br>
             &nbsp;980円</p>    
            </div>
            <div class="rec3">
            <a href="#"><img class="rec_img" src="./img/レーズン.jpg" alt="商品情報3"></a>    
            <p class="rec_font">枝付きレーズン&nbsp;<br>
             90g&nbsp;500円</p>    
            </div>
        </div>
    </section>

<div class="pagetop">上へ</div>
</main>
</body>
</html>
<footer>
    <div class="footer_left">
        <p><small class="font">株式会社XXXXXXXX&nbsp;&nbsp;TEL:0123-45-6789</small></p>
        <p><small class="font">大阪府大阪市北区梅田xx-x-x</small></p>
        <p><small class="font">&copy; Whiskey Restation All Rights Reserved.</small></p>
    </div>
    
    <div class="footer_center  font">
        <p class="font">xxxxxxxxxご利用ガイドxxxxxxx</p>
    </div>
    <div class="footer_right">
        <img src="./img/icon_f.png" alt="sns_icon1">
        <img src="./img/icon_t.png" alt="sns_icon2">
        <img src="./img/icon_i.png" alt="sns_icon3">
    </div>    
</footer>  