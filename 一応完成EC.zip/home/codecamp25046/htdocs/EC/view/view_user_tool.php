<!DOCTYPE HTML>
<html lang ="ja">
    <head>
        <meta charset ="UTF-8">
        <title>ユーザー管理view</title>
                <link rel="stylesheet" href="./css/reset.css">
        <link rel="stylesheet" href="./css/header_footer.css">
<!--        <link rel="stylesheet" href="./css/user_tool.css">-->
        <link rel="icon" href="./img/fab.jpg" sizes="18x18" type="image/jpg">

    </head>
    <header>
    <div class="header_flex">       
        <!--ロゴ-->
        <a href="./index.php"><img class="logo" src="./img/logo.png" alt="Whiskey_Restation"></a>
        
        <div>
        <p class="name"><small class="font">こんにちは<?php print $username ?>さん</small></p>

        <ul class="header_ul">
            <li class="header_li"><a class="font_li"></a></li>
            <li class="header_li"><a class="font_li" href="./about.html">About</a></li>
            <li class="header_li"><a class="font_li">Company</a></li>
            <li class="header_li"><a class="font_li">Shoplist</a></li>
            <li class="header_li"><a class="font_li">Infomation</a></li>
            <li class="header_li"><a class="font_li">Support</a></li>
            <li class="header_li"><a class="font_li" href="./logout.php">Login/out</a></li>
        </ul>
        </div>
            <!--ログイン画面へ-->
        <p><a href="./logout.php" ><img class="headericon" src="./img/key.png" alt="ログイン" ></a></p>
            <!--カートページへ-->
        <p><a href="./cart.php" ><img class="headericon" src="./img/cart.png" alt="カート"></a></p>
    </div>
    </header>
    <body>
    <h1>ユーザー管理ページ</h1>
    <p><?php print $result_msg; ?></p>
    <!--エラー内容表示 配列errors,要素errorで書く？-->
    <?php if(count($err_msg) > 0){?>
    <ul>
        <?php foreach($err_msg as $val){ ?>
        <li><?php print $val; ?></li>
        <?php } ?>
    </ul>
    <?php } ?>
    <h2>新規ユーザー追加</h2>
    <form method="post" action="user_tool.php">
    <div class="new_userbox">    
        <div><label>お名前:<input type="text" name="input_name" value=""></label></div>
        <div><label>ユーザー名:<input type="text" name="input_username" value=""></label></div>
        <div><label>パスワード:<input type="password" name="input_password" value=""></label></div>
        <div><label>mail:<input type="text" name="input_mail" value=""></label></div>
        <div><label>TEL(-あり):<input type="text" name="input_tel" value=""></label></div>
        <div><label>生年月日:<input type="text" name="input_birthdate" value="" placeholder="yyyy-mm-dd"></label></div>
        <div><label>性別:<input type="radio" name="input_sex" value="1">男性
                        <input type="radio" name="input_sex" value="2">女性</label></div>
        <div><label>郵便番号:<input type="text" name="input_postalcode" value="" placeholder="000-0000"></label></div>
        <div><label>住所:<input type="text" name="input_address" value=""></label></div>
    </div>
        <input type="submit" value="■ユーザー追加■">
        <input type="hidden" name="sql_kind" value="insert">
        <select name="visible_status">
            <option value="0">非公開</option>
            <option value="1">公開</option>
        </select>
    </form>
    <p>※ユーザー名、パスワードは半角英数字かつ6文字以上で入力すること</p>    
    <!--新規追加時はupdatetime入れない-->    
        
    <h2>ユーザー情報変更</h2>  
    <table border="1">
    <caption>ユーザー一覧</caption>
    
    <tr>
        <th>user_id</th>
        <th>お名前</th>
        <th>ユーザー名</th>
        <th>パスワード</th>
        <th>メール</th>
        <th>TEL</th>
        <th>生年月日</th>
        <th>性別</th>
        <th>郵便番号</th>
        <th>住所</th>
        <th>repeat_count</th>
        <th>create_datetime</th>
        <th>update_datetime</th>
        <th>公開状態変更</th>
    </tr>
    <!--内容を表形式で表示-->
    <?php foreach($data as $val){ ?>
    <?php if ($val['status'] === '1') { ?>
            <tr>
    <?php } else { ?>
            <tr style="background-color:#C0C0C0">
    <?php } ?>
            <td><?php print $val['user_id']; ?></td>
            <td><?php print $val['name']; ?></td>
            <td><?php print $val['user_name']; ?></td>
            <?php $val['password'] = md5($val['password']);?>
            <td><?php print $val['password']; ?></td>
            <td><?php print $val['mail']; ?></td>
            <td><?php print $val['tel']; ?></td>
            <td><?php print $val['birthdate']; ?></td>
            <td><?php print $val['sex']; ?></td>
            <td><?php print $val['postalcode']; ?></td>
            <td><?php print $val['address']; ?></td>
            <td><?php print $val['repeat_count']; ?></td>
            <td><?php print $val['create_datetime']; ?></td>
            <td><?php print $val['update_datetime']; ?></td>

        <!--<form method="post" action="user_tool.php">-->
        <!--    <td><input type="text"  name="update_stock" value="<?php print $val['stock']; ?>" size="5"></td>-->
        <!--    <td><input type="submit" value="変更"></td>-->
        <!--    <input type="hidden" name="sql_kind" value="update">-->
        <!--    <input type="hidden" name="item_id" value="<?php print $val['item_id']; ?>">-->
        <!--</form>-->

        <form method="post" action="user_tool.php">
            <td><input type="submit" value="公開/非公開"></td>
            <input type="hidden" name="change_visivle_status" value="<?php print $val['status']; ?>">
            <input type="hidden" name="sql_kind" value="change">
            <input type="hidden" name="user_id" value="<?php print $val['user_id']; ?>">
        </form>
        
    </tr>
    <?php } ?>
</table>
</body>
<footer>
    <div class="footer_left">
        <p><small class="font">株式会社XXXXXXXX&nbsp;&nbsp;TEL:0123-45-6789</small></p>
        <p><small class="font">大阪府大阪市北区梅田xx-x-x</small></p>
        <p><small class="font">&copy; Whiskey Restation All Rights Reserved.</small></p>
    </div>
    
    <div class="footer_center  font">
        
    </div>
    <div class="footer_right">
        <img src="./img/icon_f.png" alt="sns_icon1">
        <img src="./img/icon_t.png" alt="sns_icon2">
        <img src="./img/icon_i.png" alt="sns_icon3">
    </div>    
</footer> 
</html>

