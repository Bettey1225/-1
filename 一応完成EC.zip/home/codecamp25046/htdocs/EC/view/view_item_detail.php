<!DOCTYPE HTML>
<html lang ="ja">
<head>
    <meta charset ="UTF-8">
    <title>TOPページ</title>
<!--viewindex単体テスト時は単体テスト時は../だけどindex.phpから動かすときは./-->
    <link rel="stylesheet" href="./css/reset.css">
    <link rel="stylesheet" href="./css/header_footer.css">
    <link rel="stylesheet" href="./css/item_detail.css">
    <link rel="icon" href="./img/fab.jpg" sizes="18x18" type="image/jpg">
</head>
<body>

    <header>
    <div class="header_flex">       
        <!--ロゴ-->
        <a href="./index.php"><img class="logo" src="./img/logo.png" alt="Whiskey_Restation"></a>
        
        <div>
<!--        <p class="name"><small class="font">こんにちは<?php print $username ?>さん</small></p>-->

        <ul class="header_ul">
            <li class="header_li"><a class="font_li"></a></li>
            <li class="header_li"><a class="font_li" href="./about.html">About</a></li>
            <li class="header_li"><a class="font_li">Company</a></li>
            <li class="header_li"><a class="font_li">Shoplist</a></li>
            <li class="header_li"><a class="font_li">Infomation</a></li>
            <li class="header_li"><a class="font_li">Support</a></li>
            <li class="header_li"><a class="font_li" href="./logout.php">Login/out</a></li>
        </ul>
        </div>
            <!--ログイン画面へ-->
        <p><a href="./logout.php" ><img class="headericon" src="./img/key.png" alt="ログイン" ></a></p>
            <!--カートページへ-->
        <p><a href="./cart.php" ><img class="headericon" src="./img/cart.png" alt="カート"></a></p>
    </div>
    </header>

    <main>
    <p class="font_center subtitle">商品詳細</p> 
<p>パンくず予定</p>    
    <div class="flex">
        <img class="side_new" src="./img/new_glenlivet2019.jpg" alt="イベントや新商品">
        
        <div class="flex_right">
            <div class="title">
            <p>シェリー樽で21年以上熟成した特別な一樽</p>
            <p class="subtitle">シングルモルト・ウイスキー<br>『ザ・グレンリベット シングルカスク2019』</p>
            </div>
            <div class="contents1">
            <ul>
                <li>■参考小売価格：43,000円[税別]</li>
                <li>■容量：700ml</li>
                <li>■アルコール度数：55.4度(カスクストレングス)</li>
                <li>■熟成：セカンドフィルのシェリー樽で21年以上熟成した特別な一樽。</li>
                <li>■香り：洋梨とブラックベリーのアロマが上品に絡み合い、ハチミツの香りと微かなジンジャーのスパイスを感じます。</li>
                <li>■味わい：芳醇なバターショートブレッドの後に続く、やわらかなハチミツにからめた桃やアーモンドのような味わいと、ナツメグのスパイスや微かに焦がしたオークからくる味わいが絶妙なバランスを生み出します。</li>
            </ul>
            </div>
        </div>
    </div>      

    <div class="contents2">  
   
        <p>ペルノ・リカール・ジャパンが展開するシングルモル ト・ウイスキー「ザ・グレンリベット」から、
        日本限定品『ザ・グレンリベット シングルカスク2019』が4月8日から数量限定発売。
        <br>
        販売本数は1樽分の470本限定で、なくなり次第、販売終了です。</p>
        <br>
        <p>19世紀に楽しまれていたウイスキーのスタイルに忠実にあり続けようと伝統的な製法にこだわり、敢えて冷却濾過をしないノン・チルフィルタード製法を用い、
        カスクストレングス(加水調整せず、樽からそのまま瓶詰め)でボトリング。
        なめらかな口当たりと、本来のフレーバーをそのまま生かした、豊かな味わいに仕上げています。</p>
             
             
        <input class="inputbutton" type="submit" value="■カートへ入れる■">     
             
             
<!--それぞれの商品で出るように        <php foreach($data as $val){ ?>
        <php if ($val['status'] === '1') { ?>
            
                <img class="itemimg" src="<php print $img_dir.$val['img']; ?>">
                <p class="item_font">■<php print $val[1]; ?></p>
                <p class="item_font"><php print separate($val[2]); ?>円</p>
                <p class="item_font">残り<php print $val['stock']; ?>個
                <php if($val['stock']>0){ ?>
                
                    <input type="submit" value="■カートへ入れる■">
                    <input type="hidden" name="sql_kind" value="to_cart">
                    <input type="hidden" name="item_id" value="<php print $val['item_id']; ?>">
                
                <php } else { ?>
                <span  class="red">売り切れ<span>
                <php } ?>
                </p>
-->

    </div>    
    </main>
    
    <footer>
        <div class="footer_left">
            <p><small class="font">株式会社XXXXXXXX&nbsp;&nbsp;TEL:0123-45-6789</small></p>
            <p><small class="font">大阪府大阪市北区梅田xx-x-x</small></p>
            <p><small class="font">&copy; Whiskey Restation All Rights Reserved.</small></p>
        </div>
        
        <div class="footer_center  font">
            <p class="font">xxxxxxxxxご利用ガイドxxxxxxx</p>
        </div>
        <div class="footer_right">
            <img src="./img/icon_f.png" alt="sns_icon1">
            <img src="./img/icon_t.png" alt="sns_icon2">
            <img src="./img/icon_i.png" alt="sns_icon3">
        </div>    
    </footer>  
</body>
</html>