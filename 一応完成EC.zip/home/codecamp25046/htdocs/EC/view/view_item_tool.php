<!DOCTYPE HTML>
<html lang ="ja">
    <head>
        <meta charset ="UTF-8">
        <title>商品管理view</title>
        <link rel="stylesheet" href="./css/reset.css">
        <link rel="stylesheet" href="./css/header_footer.css">
<!--        <link rel="stylesheet" href="./css/item_tool.css">-->
        <link rel="icon" href="./img/fab.jpg" sizes="18x18" type="image/jpg">

        <style>
        img{
            width:80px; 
            height:auto;
        }
        </style>
    </head>
    <header>
    <div class="header_flex">       
        <!--ロゴ-->
        <a href="./index.php"><img class="logo" src="./img/logo.png" alt="Whiskey_Restation"></a>
        
        <div>
        <p class="name"><small class="font">こんにちは<?php print $username ?>さん</small></p>

        <ul class="header_ul">
            <li class="header_li"><a class="font_li"></a></li>
            <li class="header_li"><a class="font_li" href="./about.php">About</a></li>
            <li class="header_li"><a class="font_li">Company</a></li>
            <li class="header_li"><a class="font_li">Shoplist</a></li>
            <li class="header_li"><a class="font_li">Infomation</a></li>
            <li class="header_li"><a class="font_li">Support</a></li>
            <li class="header_li"><a class="font_li" href="./logout.php">Login/out</a></li>
        </ul>
        </div>
            <!--ログイン画面へ-->
        <p><a href="./logout.php" ><img class="headericon" src="./img/key.png" alt="ログイン" ></a></p>
            <!--カートページへ-->
        <p><a href="./cart.php" ><img class="headericon" src="./img/cart.png" alt="カート"></a></p>
    </div>
    </header>
    
    <body>
    <h1>商品管理ページ</h1>
    <p><?php print $result_msg; ?></p>
    <!--エラー内容表示 配列errors,要素errorで書く？-->
    <?php if(count($err_msg) > 0){?>
    <ul>
        <?php foreach($err_msg as $val){ ?>
        <li><?php print $val; ?></li>
        <?php } ?>
    </ul>
    <?php } ?>
    <h2>新規商品追加</h2>
    
    <form method="post" enctype="multipart/form-data" action="item_tool.php">
        <div><label>商品名:<input type="text" name="input_name" value=""></label></div>
        <div><label>値段:<input type="text" name="input_price" value=""></label></div>
        <div><label>個数:<input type="text" name="input_stock" value=""></label></div>
        <input type="file" name="new_img">
        <div><input type="hidden" name="err_file" value="画像が未選択です" ></div>
        <input type="submit" value="■商品追加■">
        <input type="hidden" name="sql_kind" value="insert">
        <select name="visible_status">
            <option value="0">非公開</option>
            <option value="1">公開</option>
        </select>
    </form>
        
        
        
    <h2>商品情報変更</h2>  
    <table border="1">
    <caption>商品一覧</caption>
    <tr>
        <th>商品画像</th>
        <th>商品名</th>
        <th>価格</th>
        <th>在庫</th>
        <th>在庫変更</th>
        <th>公開状態変更</th>
        <th>商品画像変更</th>
    </tr>
    <!--内容を表形式で表示-->
    <?php foreach($data as $val){ ?>
    <?php if ($val['status'] === '1') { ?>
            <tr>
    <?php } else { ?>
            <tr style="background-color:#C0C0C0">
    <?php } ?>
     
            <td><img src="<?php print $img_dir . $val['img']; ?>"></td>
            <td><?php print $val[1]; ?></td>
            <td align="right"><?php print separate($val[2]); ?></td>
    
        <form method="post" action="item_tool.php">
            <td><input type="text"  name="update_stock" value="<?php print $val['stock']; ?>" size="5"></td>
            <td><input type="submit" value="変更"></td>
            <input type="hidden" name="sql_kind" value="update">
            <input type="hidden" name="item_id" value="<?php print $val['item_id']; ?>">
        </form>
        <form method="post" action="item_tool.php">
            <td><input type="submit" value="公開/非公開"></td>
            <input type="hidden" name="sql_kind" value="change">
            <input type="hidden" name="change_visivle_status" value="<?php print $val['status']; ?>">
            <input type="hidden" name="item_id" value="<?php print $val['item_id']; ?>">
        </form>
        <form method="post" enctype="multipart/form-data" action="item_tool.php">
            <td><input type="file" name="newimg"><br>
                <input type="submit" value="画像変更"></td>
            <input type="hidden" name="sql_kind" value="imgchange">
            <input type="hidden" name="oldimg" value="<?php print $val['img']; ?>">
            <input type="hidden" name="item_id" value="<?php print $val['item_id']; ?>">
        </form>       
    </tr>
    <?php } ?>
</table>
</body>
    <footer>
    <div class="footer_left">
        <p><small class="font">株式会社XXXXXXXX&nbsp;&nbsp;TEL:0123-45-6789</small></p>
        <p><small class="font">大阪府大阪市北区梅田xx-x-x</small></p>
        <p><small class="font">&copy; Whiskey Restation All Rights Reserved.</small></p>
    </div>
    
    <div class="footer_center  font">
        
    </div>
    <div class="footer_right">
        <img src="./img/icon_f.png" alt="sns_icon1">
        <img src="./img/icon_t.png" alt="sns_icon2">
        <img src="./img/icon_i.png" alt="sns_icon3">
    </div>    
</footer>  
</html>

