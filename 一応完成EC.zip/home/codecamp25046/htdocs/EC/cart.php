<?php
// 設定ファイル読み込み
require_once './conf/const.php';
// 関数ファイル読み込み
require_once './model/function.php';


//変数初期化 
$date = date('Y-m-d H:i:s');
$data = array();
$err_msg = array();
$img_dir    = './uploadimg/';
$result_msg = '';
$sql_kind   = '';       //画面内でクリックした送信ボタンに応じて処理を振り分けるため
$result = '';
//$resultarray = array();
$rows = array();
$tmp = '';
$cartdata = array();
$update_amount = '';
$value ='';
$cartdata = array();
//エラーチェックは｢カートへ｣ボタン押した時点で在庫があるか、非公開ではないか。
//数量変更時はpurchaseから空欄やスペースのみでないか、(半角変換)数字か、
//在庫数を超えていないかのチェック。


session_start();
$user_id = $_SESSION['user_id'];

//送信ボタンがクリックされたら実行する処理
if(get_request_method() === 'POST' ){

    //返り値によって処理分岐。
    //カートへ追加時
    if (sql_kind() === 'to_cart'){
        //$user_id = '';
        $item_id = '';
    
        //$user_id = $_SESSION['user_id'];
        $item_id = get_post_data('item_id');

        //エラー処理
        if($item_id === '' ){
            $err_msg[] = '商品を選択してください。';
        
        }else{
            $dbh = get_db_connect();
            try{
                $data = get_iddata_array($dbh,$item_id);
            }catch(PDOException $e){
                //throw $e;
                $err_msg[] = '接続できませんでした。理由：'.$e->getMessage();
            }    
            //在庫チェック
            if($data[0]['stock'] <= 0){
                $err_msg[] = '在庫がなくなりました 。';
            }
            //公開状態チェック
            if($data[0]['status'] === '0'){
                $err_msg[] = '選択中の商品は非公開状態です。';
            }
            
            //すでに同じ商品が入っている場合の処理
            try{
                //レコード参照
// print $item_id;
// exit;                
//$user_id,$item_idは取れてた。
                $cartdata = get_cartdata1_array($dbh,$user_id,$item_id); 
//sql文はphpmyadminではエラーなし。                
//print $cartdata[0]['item_id'];
//print $cartdata;
//exit;
            }catch(PDOException $e){
                    //throw $e;
                $err_msg[] = '接続できませんでした。1理由：'.$e->getMessage();
            }
            //if($cartdata[0]['item_id'] !== ''){
            if(empty($cartdata) === FALSE){
                $err_msg[] = 'すでにカートに入っています。カート画面から数量を変更してください。';
            }
        }    
    
    //数量変更  
    }elseif(sql_kind() === 'update_amount'){
        //$user_id = '';
        $cart_id = '';
        $update_amount = '';
        $item_id = '';

        //$user_id = $_SESSION['user_id'];
        $cart_id = get_post_data('cart_id');
        $update_amount = get_post_data('update_amount');
        $update_amount = convert(isset_replace($update_amount));
        $item_id = get_post_data('item_id');
       
        $dbh = get_db_connect();
            try{
                $data = get_iddata_array($dbh,$item_id);
            }catch(PDOException $e){
                    //throw $e;
                    $err_msg[] = '接続できませんでした。理由：'.$e->getMessage();
            }
        //在庫チェック
        if($data[0]['stock'] <= 0){
            $err_msg[] = '在庫がなくなりました 。';
        }
        //エラーチェック
        if($update_amount === '' || spaceonly($update_amount) === TRUE){
            $err_msg[] = '数量が空欄です。';
        }    
        if(ctype_digit($update_amount) === FALSE){
            $err_msg[] = '数量は正の整数で入力してください。';
        }
    
    //商品削除        　本当ならフラグ立てて裏で残しておきたいけど
    }elseif(sql_kind() === 'delete_cartrow'){
        $cart_id = '';
        $cart_id = get_post_data('cart_id');

    }
            
    
    //エラーが1つもない場合
     
    if(count($err_msg) === 0){
        $dbh = get_db_connect();
        if(sql_kind() === 'to_cart' ){

            try{
                //★トランザクション開始
                $dbh->beginTransaction();
                try{
                    //レコード参照
                    $cartdata = get_cartdata1_array($dbh,$user_id,$item_id);
                    //$update_stock = $data[0]['stock'] -1 ;

                     //カートへ追加。
                    $sql = "INSERT INTO cart(user_id,item_id,amount,create_datetime)
                            VALUES('$user_id','$item_id','1','$date')"; 
    
                    // // クエリ実行(関数にこのSQL文を渡す。)      fetchが入ってるためにGeneralerror2053？
                     //$data = get_as_array($dbh, $sql);

                     //SQL実行準備    
                    $stmt = $dbh->prepare($sql);     
                    //バインドなし    
                    //SQL実行
                    $stmt->execute();
                    //コミット 
                    $dbh->commit();   
                    $result_msg ='カートへ追加しました。';
                }catch (PDOException $e) {
                    // ロールバック
                    $dbh->rollback();
                    // 例外をスロー
                    throw $e;
                }
            }catch(PDOException $e){
                //throw $e;
                $err_msg[] = 'カートへ追加処理で接続できませんでした。理由：'.$e->getMessage();
            }
        }elseif(sql_kind() === 'update_amount'){
            try{
                //★トランザクション開始
                $dbh->beginTransaction();
                try{
                    $result = update_cart($dbh,$cart_id,$update_amount,$date);
                    
                    //コミット 
                    $dbh->commit();   
                    $result_msg ='購入数量を変更しました。';
                }catch (PDOException $e) {
                    // ロールバック
                    $dbh->rollback();
                    // 例外をスロー
                    throw $e;
                }
            }catch(PDOException $e){
                //throw $e;
                $err_msg[] = '購入数量を変更できませんでした。理由：'.$e->getMessage();
            }
        //商品削除        
        }elseif(sql_kind() === 'delete_cartrow'){
            try{
                //★トランザクション開始
                $dbh->beginTransaction();
                try{
                    $result = delete_cartrow($dbh,$cart_id);
                    
                    //コミット 
                    $dbh->commit();   
                    $result_msg ='カートから選択商品を削除しました。';
                }catch (PDOException $e) {
                    // ロールバック
                    $dbh->rollback();
                    // 例外をスロー
                    throw $e;
                }
            }catch(PDOException $e){
                //throw $e;
                $err_msg[] = '選択商品を削除できませんでした。理由：'.$e->getMessage();
            }
        }
    }
}else{
    //$err_msg[] = 'エラー!商品購入ページへ戻ってください。';
    $err_msg[] = '商品一覧以外から来ました。';
} 


//常に実行する処理 
//データベースに接続し、すでに登録されている内容をSELECTで参照。
//そのユーザーのカート情報JOINして表示
try{
    $dbh = get_db_connect();
    //SQL生成
    $sql = 'SELECT *
            FROM cart 
            INNER JOIN item_master
            ON cart.item_id = item_master.item_id
            INNER JOIN item_stock_master
            ON item_master.item_id = item_stock_master.item_id
            WHERE user_id = '.$user_id;
        //ORDERBY外したらエラーなくなった。
        
            //↓これは該当ユーザーのみ出るけど内容量などでエラー
            //INNER JOIN item_master
            //ON cart.item_id = item_stock_master.item_id

            // SELECT *
            // FROM cart 
            // INNER JOIN item_master
            // ON cart.item_id = item_master.item_id
            // INNER JOIN item_stock_master
            // ON item_master.item_id = item_stock_master.item_id
            
            // ORDER BY cart_id asc
            
    // クエリ実行(関数にこのSQL文を渡す。)
    $data = get_as_array($dbh, $sql);
}catch(PDOException $e){
    //throw $e;
    $err_msg[] = '接続できませんでした。理由：'.$e->getMessage();
}

// try{
//     //$dbh = get_db_connect();
//     $cartdata = get_cartdata2_array($dbh,$user_id);
// }catch(PDOException $e){
//     $err_msg[] = '接続できませんでした。2理由：'.$e->getMessage();
// }


//アイテムの種類でなくて数量合計
// //SELECT COUNT( * ) FROM cart;
// 'SELECT
// //   SUM(price)  as price,
// //   SUM(amount) as amount
// // FROM cart
// // GROUP BY user_id;
// // HAVING user_id = '.$user_id;
$itemamount = '';
$moneyamount = '';

foreach ($data as $value) {
    $itemamount = $itemamount + $value['amount'];
    $moneyamount = $moneyamount + $value['price'] * $value['amount'];
}


//表示順はSELECT文中にasc/desc。
//var_dump($data);

//エンティティ化
$data = ent2($data);
//$cartdata = ent2($cartdata);

//表示ファイル読み込み
//session_start();

if (isset($_SESSION['user_name'])) {
    $username = $_SESSION['user_name'];
    $user_id = $_SESSION['user_id'];
}else{
    header('Location:./login.php');
    exit;
}
include_once './view/view_cart.php';
 