<?php

// 設定ファイル読み込み
require_once './conf/const.php';
// 関数ファイル読み込み
require_once './model/function.php';


//変数初期化 
//$img_dir    = './uploadimg/';
$date = date('Y-m-d H:i:s');
$data = array();
$err_msg = array();
$result_msg = '';
$sql_kind   = '';       //画面内でクリックした送信ボタンに応じて処理を振り分けるため
$result = '';
//$resultarray = array();
$rows = array();
$tmp = '';

//送信ボタンがクリックされたら実行する処理
if(get_request_method() === 'POST' ){
    //返り値によって処理分岐できる
    if (sql_kind() === 'login') {
        $check_username = '';
        $check_password = '';
   
        //labelのnameを引数に。空でなければユーザーが入力したユーザーが入力した値が返ってくる。
        $check_username = get_post_data('check_username');
        $check_password = get_post_data('check_password');
       
        //空欄でないか、前後にスペース等ついていないかのチェックというか置換で消す。
        $check_username = convert(isset_replace($check_username));
        $check_password = convert(isset_replace($check_password));
  
        //エラー処理
        //名前欄、発言欄いずれかが空欄・全角半角スペースのみの場合もエラーを出す。
        //文字数制限(mb_strlenは全角も半角も1文字としてカウント)
        if($check_username === '' || spaceonly($check_username) === TRUE){
            $err_msg[] = 'ユーザー名が空欄です。';
        }
        elseif(mb_strlen($check_username) > 50 || mb_strlen($check_username) < 6){
            $err_msg[] = 'ユーザー名は6文字以上で入力してください。';
        }
        if($check_password === '' || spaceonly($check_password) === TRUE){
            $err_msg[] = 'パスワードが空欄です。';
        }
        elseif(mb_strlen($check_password) > 50 || mb_strlen($check_password) < 6){
            $err_msg[] = 'パスワードは6文字以上で入力してください。';
        }

        //半角英数字かチェック
        $username_regex = '/^[0-9a-zA-Z]{6,50}$/';
        $password_regex = '/^[0-9a-zA-Z]{6,50}$/';
        
        // バリデーション実行
        if( preg_match($username_regex, $check_username) === 0 ) {
          $err_msg[] = 'ユーザー名は6文字以上50文字以内の半角英数字で入力してください。';
        }
        if( preg_match($password_regex, $check_password) === 0 ) {
          $err_msg[] = 'パスワードは6文字以上50文字以内の半角英数字で入力してください。';
        }
// //公開状態のバリデーションをinsert,change追記        
//         if($status !== '0' && $status !== '1'){
//             $err_msg[] = '無効なステータスです。';
//         }

//var_dump($err_msg);
    }

    //エラーが1つもない場合
    //データベースに接続し、ユーザー情報取得。セッション開始。
    if(count($err_msg) === 0){
        $dbh = get_db_connect();
        
        if(sql_kind() === 'login' ){
            try{
                //★トランザクション開始
                $dbh->beginTransaction();
                try{
                    $result = get_user($dbh, $check_username, $check_password);

                    // // リロード対策でリダイレクト
                    // header('Location: http://'. $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
                    // exit;
                    if ($result !== FALSE) {
                    
                    // セッション開始
                    session_start();
                    // セッション変数に値を保存
                    $_SESSION['user_id'] = $result[0]['user_id'];
                    //$_SESSION['user_id'] = $result[0]['user_id'];
                    $_SESSION['user_name'] = $check_username;
             
                    //これは？
                    // $url_root = dirname($_SERVER["REQUEST_URI"]).'/';
                    // header('Location: http://'. $_SERVER['HTTP_HOST'] . $url_root . './view/view_index.php');
                    header('Location:./index.php');
                    exit;    
                    } else {
                      $err_msg[] = 'ユーザー名またはパスワードが違います。';
                    }
                    
                    //コミット 
                    $dbh->commit();   
                    //$result_msg ='登録しました。';
                }catch (PDOException $e) {
                // ロールバック
                $dbh->rollback();
                // 例外をスロー
                throw $e;
                }
            }catch(PDOException $e){
            //throw $e;
            $err_msg[] = 'ユーザー名またはパスワードが違います。理由：'.$e->getMessage();
                
            }
        }
    }
} 
//常に実行する処理 


//表示ファイル読み込み
include_once './view/view_login.php';

//$dbh=NULL;
 